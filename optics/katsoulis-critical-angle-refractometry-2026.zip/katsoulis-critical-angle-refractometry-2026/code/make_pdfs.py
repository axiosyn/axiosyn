r"""Build typeset PDFs of the three papers from their Markdown sources.

usage: python make_pdfs.py <src1.md> <out1.pdf> [<src2.md> <out2.pdf> ...]

- LaTeX code blocks -> KaTeX display math
- image placeholders (&#91;image: ALT\]) -> figures from analysis/figures, by alt text
- plain-text subscripts/superscripts (n_TM, ^{1/2}) -> <sub>/<sup> outside code and math
- A4 journal-style layout, page numbers, printed with headless Microsoft Edge
"""
import html
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import markdown

HERE = Path(__file__).resolve().parent
FIGS = HERE / "figures"
BUILD = HERE.parent / "papers" / "build"
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
AUTHOR = "Ierotheos Katsoulis"

FIG_BY_ALT = {
    "Prism-coupling geometry": "fig1_geometry.png",
    "Reflectance profiles": "fig2_profiles.png",
    "Example profiles": "fig2_profiles.png",
    "Rotation-direction offset": "fig3_rotation.png",
    "Rotation offset": "fig3_rotation.png",
    "Bias model": "fig4_bias_model.png",
    "Anisotropy": "fig5_anisotropy.png",
    "Dispersion": "fig6_dispersion.png",
    "Temperature dependence": "fig7_temperature.png",
    "Generalized artefact": "figM1_generalized.png",
    "Measured and model profiles": "figT2_profiles.png",
    "Refractive index of Intralipid and cream": "figT1_turbid.png",
}

CSS = r"""
@page { size: A4; margin: 20mm 18mm 20mm 18mm;
        @bottom-center { content: counter(page); font: 9pt 'Cambria', 'Times New Roman', serif; color: #555; } }
html { font-family: 'Cambria', 'Times New Roman', serif; font-size: 10.5pt; line-height: 1.42; color: #111; }
body { margin: 0; }
h1 { font-size: 17pt; line-height: 1.25; margin: 0 0 6pt 0; font-weight: 700; }
.byline { font-size: 10pt; color: #444; margin: 0 0 14pt 0; }
.release-note { font-size: 8.6pt; line-height: 1.35; color: #333; border: 0.6pt solid #c8c7c1; background: #f6f6f3;
                padding: 6pt 8pt; margin: -6pt 0 14pt 0; text-align: left; break-inside: avoid; }
h2 { font-size: 12.5pt; margin: 16pt 0 5pt 0; break-after: avoid; }
h3 { font-size: 11pt; font-style: italic; font-weight: 600; margin: 11pt 0 4pt 0; break-after: avoid; }
p { margin: 0 0 6pt 0; text-align: justify; hyphens: auto; }
ol, ul { margin: 0 0 6pt 0; padding-left: 18pt; }
li > p { margin: 0 0 3pt 0; }
code { font-family: Consolas, 'Courier New', monospace; font-size: 8.8pt; }
img { display: block; max-width: 100%; max-height: 105mm; margin: 8pt auto 3pt auto; break-inside: avoid; }
p:has(> img) { break-after: avoid; margin: 0; }
p.caption { font-size: 9pt; line-height: 1.3; color: #333; margin: 0 0 10pt 0; text-align: left; }
p.caption b { color: #111; }
table { border-collapse: collapse; margin: 6pt auto 3pt auto; font-size: 9pt; break-inside: avoid; }
th, td { border-top: 0.6pt solid #999; border-bottom: 0.6pt solid #999; padding: 2.5pt 6pt; text-align: left; vertical-align: top; }
thead th { border-top: 1.2pt solid #111; border-bottom: 0.9pt solid #111; }
tbody tr:last-child td { border-bottom: 1.2pt solid #111; }
.math { margin: 6pt 0 8pt 0; overflow: hidden; }
.katex-display { margin: 0; }
a { color: #1c5cab; text-decoration: none; }
h2#references + ol, h2#references ~ ol { font-size: 9pt; line-height: 1.3; }
h2#references ~ ol li p { text-align: left; }
"""

TEMPLATE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>{title}</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"
  onload="renderMathInElement(document.body,{{delimiters:[{{left:'\\\\[',right:'\\\\]',display:true}}],throwOnError:false}});document.body.setAttribute('data-math','done');"></script>
<style>{css}</style></head>
<body>{body}</body></html>"""

def preprocess(md: str) -> str:
    lines = md.splitlines()
    # byline: "Nov 4, 2026 · @Iero" -> author + date
    for i, l in enumerate(lines[:6]):
        m = re.match(r"^([A-Z][a-z]{2} \d{1,2}, \d{4}) · @\S+(?:\s*·\s*\S.*)?$", l.strip())
        if m:
            lines[i] = f'<p class="byline">{AUTHOR} · draft of {m[1]}</p>'
            break
    md = "\n".join(lines)
    # images
    def img(m):
        alt = m[1].strip()
        f = FIG_BY_ALT.get(alt)
        if not f:
            raise SystemExit(f"no figure mapped for placeholder alt text: {alt!r}")
        size = "{: style=\"max-width:58%\"}" if f == "fig1_geometry.png" else ""
        return f"![{alt}](figs/{f}){size}"
    md = re.sub(r"&#91;image: (.+?)\\\]", img, md)
    # display math
    def math(m):
        tex = m[1].strip()
        return f'\n<div class="math">\\[{html.escape(tex, quote=False)}\\]</div>\n'
    md = re.sub(r"```latex\n(.*?)\n```", math, md, flags=re.S)
    # task-list boxes
    md = re.sub(r"^(\s*)- \[ \] ", r"\1- ☐ ", md, flags=re.M)
    return md

SUB = re.compile(r"(?<=[A-Za-z\u0370-\u03ff\)])_(\{[^}]+\}|[A-Za-z0-9\u0370-\u03ff]+)")
SUP = re.compile(r"\^\{([^}]+)\}")

def scripts(text: str) -> str:
    text = SUB.sub(lambda m: "<sub>" + m[1].strip("{}") + "</sub>", text)
    return SUP.sub(lambda m: "<sup>" + m[1] + "</sup>", text)

def postprocess(h: str) -> str:
    # apply sub/superscripts only to text outside tags, <code>, <pre>, math divs and <a href>
    out, skip = [], 0
    for part in re.split(r"(<[^>]+>)", h):
        if part.startswith("<"):
            t = part.lower()
            if re.match(r"<(code|pre)\b", t) or t.startswith('<div class="math"'):
                skip += 1
            elif re.match(r"</(code|pre)>", t) or (t == "</div>" and skip):
                skip = max(skip - 1, 0)
            out.append(part)
        else:
            out.append(part if skip else scripts(part))
    h = "".join(out)
    # captions
    h = re.sub(r"<p>((?:Fig\.|Table) \d+\.)", r'<p class="caption"><b>\1</b>', h)
    return h

def build(src: Path, out: Path):
    BUILD.mkdir(parents=True, exist_ok=True)
    (BUILD / "figs").mkdir(exist_ok=True)
    for f in set(FIG_BY_ALT.values()):
        shutil.copy2(FIGS / f, BUILD / "figs" / f)
    md = preprocess(src.read_text(encoding="utf-8"))
    title = md.splitlines()[0].lstrip("# ").strip()
    body = markdown.markdown(md, extensions=["tables", "sane_lists", "attr_list", "toc"])
    body = postprocess(body)
    page = BUILD / (out.stem + ".html")
    page.write_text(TEMPLATE.format(title=html.escape(title), css=CSS, body=body), encoding="utf-8")
    cmd = [EDGE, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--run-all-compositor-stages-before-draw",
           "--virtual-time-budget=20000", f"--print-to-pdf={out}", page.as_uri()]
    subprocess.run(cmd, check=True, timeout=180, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"wrote {out} ({out.stat().st_size} bytes) from {page.name}")

if __name__ == "__main__":
    args = sys.argv[1:]
    for s, o in zip(args[0::2], args[1::2]):
        build(Path(s), Path(o))
