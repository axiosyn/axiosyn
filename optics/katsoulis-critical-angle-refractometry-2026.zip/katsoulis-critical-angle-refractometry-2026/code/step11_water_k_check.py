"""Step 11 (validation): does the edge-shape fit of step 9 recover the known absorption of water?

Same model as step 9, R = a + b * R_coh(theta + dth; n + i k, sigma), applied to the 25 C water
scans (raw counts; a, b absorb the missing air normalization). Water's k is known
(1.5e-9 at 532 ... 1.3e-4 at 1551 nm), so the fitted k shows the bias floor of the method:
whatever k it returns for water at a given wavelength is an upper limit on how much of the
Intralipid k could be a fitting artefact.
Rotation offset: L scans read high and R scans low by 'lag' (step 2), shifted accordingly.
Output: results/water_k_check.csv
"""
import csv
import math
import os
import sys

import numpy as np
from scipy.optimize import least_squares

import water_lib as W

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
DATA = os.path.join(HERE, "..", "Ierotheos")
SIG = {int(r["lam"]): float(r["sigma"]) for r in csv.DictReader(open(os.path.join(RES, "blur_inference.csv"), encoding="utf-8"))
       if float(r["T"]) == 25.0}
LAG = {}
for r in csv.DictReader(open(os.path.join(RES, "n_corrected.csv"), encoding="utf-8")):
    if float(r["T"]) == 25.0:
        LAG.setdefault(int(r["lam"]), []).append(float(r["lag"]))
LAG = {k: float(np.mean(v)) for k, v in LAG.items()}


def fit(th, I, pol, n_p, sig, dth, n0, slope):
    t0 = th.mean()
    scale = float(np.median(I[th > th.mean() + 1.0]))
    y = I / scale

    def model(p):
        n, lk, a, b = p[:4]
        s = p[4] if slope else 0.0
        return a + s * (th - t0) + b * W.blurred_R(th + dth, (n + 1j * 10 ** lk) / n_p, pol, sig)

    best = None
    for lk0 in (-5.0, -4.0, -3.5, -3.0):
        x0 = [n0, lk0, 0.0, 1.0] + ([0.0] if slope else [])
        lo = [n0 - 0.005, -7, -0.3, 0.5] + ([-1] if slope else [])
        hi = [n0 + 0.005, -1.5, 0.5, 1.5] + ([1] if slope else [])
        r = least_squares(lambda p: model(p) - y, x0, bounds=(lo, hi))
        if best is None or r.cost < best.cost:
            best = r
    return 10 ** best.x[1], best.x[2], math.sqrt(2 * best.cost / max(len(th) - len(best.x), 1))


def main():
    rows = []
    for s in W.load_all(DATA):
        if s.T_nominal != 25 or s.direction not in ("L", "R") or s.lam not in SIG:
            continue
        I, _ = W.despike(s.I)
        st = W.sdm_stats(s.theta, I, s.n_prism)
        thc = st["theta_c"]
        sign = 1.0 if s.direction == "R" else -1.0            # R reads low -> shift angle up
        dth = sign * math.degrees(LAG[s.lam] / (s.n_prism * math.cos(math.radians(thc))))
        m = (s.theta > thc - 2.0) & (s.theta < thc + 2.0)
        n0 = st["n_sdm"]
        k0, a0, r0 = fit(s.theta[m], I[m], s.pol, s.n_prism, SIG[s.lam], dth, n0, False)
        k1, a1, r1 = fit(s.theta[m], I[m], s.pol, s.n_prism, SIG[s.lam], dth, n0, True)
        rows.append(dict(file=os.path.basename(s.path), lam=s.lam, pol=s.pol, dir=s.direction,
                         k_true=W.K_WATER[s.lam], k_fit=k0, a=a0, rms=r0, k_fit_slope=k1, a_slope=a1, rms_slope=r1))
    with open(os.path.join(RES, "water_k_check.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(f"{len(rows)} water scans (25 C)")
    for lam in sorted({r["lam"] for r in rows}):
        for pol in ("TE", "TM"):
            s = [r for r in rows if r["lam"] == lam and r["pol"] == pol]
            if not s:
                continue
            k = np.array([r["k_fit"] for r in s]); ks = np.array([r["k_fit_slope"] for r in s])
            print(f"{lam:5d} {pol} N={len(s):2d}  k_true={W.K_WATER[lam]:.1e}  k_fit median={np.median(k):.2e} "
                  f"(IQR {np.percentile(k, 25):.1e}-{np.percentile(k, 75):.1e})  with slope {np.median(ks):.2e}  "
                  f"a={np.median([r['a'] for r in s]):.3f}  -> excess mu = {4 * math.pi * (np.median(k) - W.K_WATER[lam]) / (lam * 1e-6):.2f} /mm")


if __name__ == "__main__":
    main()
