"""Step 3: publication figures -> figures/*.png (300 dpi) and *.pdf"""
import csv
import json
import math
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Polygon, FancyArrowPatch

import water_lib as W

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
FIG = os.path.join(HERE, "figures")
os.makedirs(FIG, exist_ok=True)

# ---- style: one identity per polarization across the paper (color + marker shape)
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e4e3df"
C = {"TE": "#2a78d6", "TM": "#eb6834"}
MK = {"TE": "o", "TM": "s"}
plt.rcParams.update({
    "font.size": 8.5, "axes.labelsize": 8.5, "axes.titlesize": 9, "legend.fontsize": 7.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 1.6, "savefig.dpi": 300,
    "legend.frameon": False, "figure.dpi": 110, "font.family": "DejaVu Sans",
})

def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"), bbox_inches="tight")
    fig.savefig(os.path.join(FIG, name + ".pdf"), bbox_inches="tight")
    plt.close(fig)
    print("wrote", name)

def rd(name):
    rows = list(csv.DictReader(open(os.path.join(RES, name), encoding="utf-8")))
    for r in rows:
        for k, v in r.items():
            try:
                r[k] = float(v)
            except (ValueError, TypeError):
                pass
    return rows

scans, ncor, aniso, inf, pav = rd("scans.csv"), rd("n_corrected.csv"), rd("anisotropy.csv"), rd("blur_inference.csv"), rd("n_pol_avg.csv")
summ = json.load(open(os.path.join(RES, "summary.json")))
DATA = os.path.join(HERE, "..", "Ierotheos")

# =========================================================== Fig 1: geometry
fig, ax = plt.subplots(figsize=(3.4, 2.3))
ax.set_axis_off(); ax.set_aspect("equal")
prism = Polygon([[-1.6, 0], [1.6, 0], [0, 1.6]], closed=True, fc="#eef3fb", ec=INK2, lw=1)
ax.add_patch(prism)
ax.add_patch(Polygon([[-1.9, -0.9], [1.9, -0.9], [1.9, 0], [-1.9, 0]], closed=True, fc="#d9e8f7", ec=INK2, lw=1))
ax.add_patch(Polygon([[-0.35, -0.02], [0.35, -0.02], [0.35, -0.12], [-0.35, -0.12]], closed=True, fc="white", ec="none"))
ax.text(0, -0.55, "water sample (cell)  $n = n_r + i\\,k$", ha="center", va="center", color=INK, fontsize=7.5)
ax.text(0, 0.95, "prism\n$n_p(\\lambda,T)$", ha="center", va="center", color=INK, fontsize=7.5)
ax.annotate("", xy=(0, 0), xytext=(-1.25, 1.25), arrowprops=dict(arrowstyle="-|>", color=C["TE"], lw=1.4))
ax.annotate("", xy=(1.35, 1.35), xytext=(0, 0), arrowprops=dict(arrowstyle="-|>", color=C["TE"], lw=1.4))
ax.plot([0, 0], [0, 1.3], ls=":", color=MUTED, lw=0.8)
ax.text(-0.22, 0.35, "$\\theta$", color=INK, fontsize=9)
ax.text(-1.9, 1.35, "laser\n(TE or TM)", fontsize=7, color=INK2, va="center")
ax.text(1.45, 1.45, "photo-\ndetector", fontsize=7, color=INK2, va="bottom")
ax.annotate("", xy=(1.9, 0.75), xytext=(1.55, 0.25), arrowprops=dict(arrowstyle="<->", color=MUTED, lw=0.8, connectionstyle="arc3,rad=0.4"))
ax.text(1.95, 0.45, "table\nrotation\n(L / R)", fontsize=6.5, color=INK2, va="center")
ax.set_xlim(-2.2, 2.6); ax.set_ylim(-1.0, 1.9)
save(fig, "fig1_geometry")

# =========================================================== Fig 2: example profiles
fig, axs = plt.subplots(2, 2, figsize=(7.0, 4.4), sharex="col", gridspec_kw=dict(height_ratios=[1.3, 1]))
for j, lam in enumerate((633, 1551)):
    for pol in ("TE", "TM"):
        s = W.load_scan(os.path.join(DATA, f"water_{lam}_25_{pol}_003_L.csv"))
        I = W.despike(s.I)[0]
        st = W.sdm_index(s)
        x = s.theta - st["theta_c"]
        _, dI, _ = W.derivative_peak(s.theta, I)
        axs[0, j].plot(x, I / st["plateau"], color=C[pol], lw=1.4, label=pol)
        axs[1, j].plot(x, dI / dI.max(), color=C[pol], lw=1.4, label=pol)
    axs[0, j].set_title(f"{lam} nm, 25 °C", loc="left", color=INK)
    axs[0, j].set_ylabel("$I/I_{\\mathrm{TIR}}$")
    axs[1, j].set_ylabel("$(dI/d\\theta)/\\max$")
    axs[1, j].set_xlabel("$\\theta-\\theta_c$  (deg)")
    axs[1, j].set_xlim(-1.5, 0.8)
    for a in axs[:, j]:
        a.axvline(0, color=MUTED, lw=0.8, ls="--")
    axs[0, j].legend(loc="lower right")
fig.align_ylabels(axs[:, 0])
save(fig, "fig2_profiles")

# =========================================================== Fig 3: rotation direction
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.6), gridspec_kw=dict(width_ratios=[1.5, 1]))
ax = axs[0]
sel = [r for r in scans if r["lam"] == 1551 and r["pol"] == "TE"]
sel.sort(key=lambda r: r["time"])
mu = np.mean([r["n_w15"] for r in sel])
for i, r in enumerate(sel):
    filled = r["direction"] == "L"
    ax.plot(i, (r["n_w15"] - mu) * 1e4, marker="o", ms=5.5, color=C["TE"], mfc=C["TE"] if filled else "white", mew=1.2, ls="none")
ax.plot([], [], "o", color=C["TE"], label="L rotation"); ax.plot([], [], "o", color=C["TE"], mfc="white", label="R rotation")
ax.axhline(0, color=MUTED, lw=0.8)
ax.set_xlabel("scan number (chronological)"); ax.set_ylabel("$n_{\\mathrm{SDM}}-\\langle n\\rangle$  ($10^{-4}$)")
ax.set_title("1551 nm, TE, 25 °C", loc="left"); ax.legend(loc="center right")
ax = axs[1]
labels = []
for i, c in enumerate([c for c in ncor if not math.isnan(c["lag"])]):
    ax.errorbar(i, c["lag"] * 2e4, yerr=0, marker=MK[c["pol"]], color=C[c["pol"]], ms=5.5, ls="none")
    labels.append(f"{int(c['lam'])}/{int(c['T'])}")
ax.set_xticks(range(len(labels)))
ax.set_xticklabels(labels, rotation=90, fontsize=6.5)
lags = np.array([c["lag"] for c in ncor if not math.isnan(c["lag"])])
ax.axhline(lags.mean() * 2e4, color=MUTED, lw=0.8, ls="--")
ax.set_ylabel("$n_L-n_R$  ($10^{-4}$)"); ax.set_ylim(0, 13)
ax.set_title("all conditions (nm/°C)", loc="left")
ax.plot([], [], MK["TE"], color=C["TE"], label="TE"); ax.plot([], [], MK["TM"], color=C["TM"], label="TM"); ax.legend(loc="lower right", ncol=2)
save(fig, "fig3_rotation")

# =========================================================== Fig 4: derivative-method bias model
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.7))
sig = np.linspace(0.0, 0.05, 26)
for lam, ls in ((633, "-"), (1551, "--")):
    npz = {633: 1.9642, 1551: 1.934}[lam]; n0 = {633: 1.3305, 1551: 1.3151}[lam]
    b = {p: np.array([W.sdm_bias(lam, p, n0, W.K_WATER[lam], npz, s) for s in sig]) for p in ("TE", "TM")}
    for p in ("TE", "TM"):
        axs[0].plot(sig, b[p] * 1e4, ls=ls, color=C[p], label=f"{p}, {lam} nm")
    axs[1].plot(sig, (b["TM"] - b["TE"]) * 1e5, ls=ls, color=INK2, label=f"{lam} nm (k from lit.)")
axs[0].set_xlabel("angular spread $\\sigma$ (deg)"); axs[0].set_ylabel("$n_{\\mathrm{SDM}}-n$  ($10^{-4}$)")
axs[0].legend(ncol=1, loc="lower left"); axs[0].set_title("(a) bias of the derivative method", loc="left")
OFFS = {(633, 25): (-30, 6), (964, 25): (6, -10), (1551, 25): (-12, 9), (532, 25): (6, -4)}
for r in inf:
    a = next(x for x in aniso if x["lam"] == r["lam"] and x["T"] == r["T"])
    if a["u_meas"] > 2e-5:      # 50-80 C runs: too imprecise to show here (see Fig. 5)
        continue
    axs[1].errorbar(r["sigma"], a["d_meas"] * 1e5, xerr=r["sigma_u"], yerr=a["u_meas"] * 1e5, fmt="D", ms=4,
                    color=INK, mfc="white", ecolor=MUTED, elinewidth=0.8, capsize=0, zorder=5)
    axs[1].annotate(f"{int(r['lam'])} nm", (r["sigma"], a["d_meas"] * 1e5),
                    xytext=OFFS.get((int(r["lam"]), int(r["T"])), (5, 3)), textcoords="offset points",
                    fontsize=6.5, color=INK2)
axs[1].plot([], [], "D", color=INK, mfc="white", label="measured $n_{TM}-n_{TE}$")
axs[1].set_xlabel("angular spread $\\sigma$ (deg)"); axs[1].set_ylabel("$n_{TM}-n_{TE}$  ($10^{-5}$)")
axs[1].set_ylim(-2, 14); axs[1].legend(loc="upper left")
axs[1].set_title("(b) apparent anisotropy", loc="left")
save(fig, "fig4_bias_model")

# =========================================================== Fig 5: anisotropy result
fig, ax = plt.subplots(figsize=(7.0, 2.8))
good = [a for a in aniso if a["u_cor"] < 2e-4]
for i, a in enumerate(good):
    ax.errorbar(i - 0.12, a["d_meas"] * 1e5, yerr=a["u_meas"] * 1e5, fmt="o", ms=5, color=MUTED, mfc="white", elinewidth=0.9, capsize=0)
    ax.errorbar(i + 0.12, a["d_cor"] * 1e5, yerr=a["u_cor"] * 1e5, fmt="o", ms=5, color=INK, elinewidth=0.9, capsize=0)
    ax.plot([i - 0.32, i + 0.32], [a["d_pred"] * 1e5] * 2, color=C["TM"], lw=1.6)
m, u = summ["corrected_TM_minus_TE"] * 1e5, summ["corrected_TM_minus_TE_u"] * 1e5
ax.axhspan(m - 2 * u, m + 2 * u, color=GRID, zorder=0)
ax.axhline(0, color=INK2, lw=0.8)
ax.set_xticks(range(len(good)))
ax.set_xticklabels([f"{int(a['lam'])} nm\n{int(a['T'])} °C" for a in good])
ax.set_ylabel("$n_{TM}-n_{TE}$  ($10^{-5}$)")
ax.plot([], [], "o", color=MUTED, mfc="white", label="measured (derivative method)")
ax.plot([], [], "-", color=C["TM"], label="predicted method artefact")
ax.plot([], [], "o", color=INK, label="corrected")
ax.fill_between([], [], color=GRID, label="weighted mean ±2σ")
ax.legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.16))
ax.set_ylim(-15, 30)
save(fig, "fig5_anisotropy")

# =========================================================== Fig 6: dispersion at 25 C
fig, axs = plt.subplots(2, 1, figsize=(3.4, 4.2), sharex=True, gridspec_kw=dict(height_ratios=[1.4, 1]))
lam = np.linspace(500, 1600, 300)
ia = W.n_iapws_rel_air(lam, 25.0)
axs[0].plot(lam, ia, color=INK2, lw=1.3, label="IAPWS R9-97 (rel. air)")
axs[0].plot(lam[lam > 1100], ia[lam > 1100], color="white", lw=1.6, ls=(0, (2, 2)))
# Kedenburg 20 C, moved to 25 C with the IAPWS thermo-optic coefficient
ked = W.n_kedenburg_20c(lam) + (W.n_iapws_vac(lam, 25) - W.n_iapws_vac(lam, 20))
axs[0].plot(lam, ked, color=MUTED, lw=1.0, ls="--", label="Kedenburg 2012 (→25 °C)")
for p in ("TE", "TM"):
    v = [c for c in ncor if c["T"] == 25 and c["pol"] == p]
    off = -6 if p == "TE" else 6
    axs[0].errorbar([c["lam"] + off for c in v], [c["n_cor"] for c in v], fmt=MK[p], ms=4.5, color=C[p], label=p)
    axs[1].errorbar([c["lam"] + off for c in v], [(c["n_cor"] - c["n_iapws_air"]) * 1e4 for c in v],
                    yerr=[c["u_rel"] * 1e4 for c in v], fmt=MK[p], ms=4.5, color=C[p], elinewidth=0.9, capsize=0)
axs[1].plot(lam, (ked - ia) * 1e4, color=MUTED, lw=1.0, ls="--")
axs[1].axhline(0, color=INK2, lw=1.0)
axs[1].axhspan(-8, 8, color=GRID, zorder=0)
axs[0].set_ylabel("$n$ at 25 °C"); axs[0].legend(loc="upper right")
axs[1].set_ylabel("$n-n_{\\mathrm{IAPWS}}$ ($10^{-4}$)"); axs[1].set_xlabel("wavelength (nm)")
axs[1].set_ylim(-14, 14)
fig.align_ylabels(axs)
save(fig, "fig6_dispersion")

# =========================================================== Fig 7: temperature
session = {(532, 25): "B", (532, 50): "A", (532, 80): "A", (532, 70): "D", (633, 50): "A", (633, 52): "A", (633, 70): "C", (633, 25): "C"}
SMK = {"A": "^", "B": "v", "C": "o", "D": "D"}
fig, axs = plt.subplots(2, 2, figsize=(7.0, 4.0), sharex=True, gridspec_kw=dict(height_ratios=[1.4, 1]))
T = np.linspace(20, 85, 100)
for j, lamv in enumerate((532, 633)):
    axs[0, j].plot(T, W.n_iapws_rel_air(lamv, T), color=INK2, lw=1.3, label="IAPWS R9-97 (rel. air)")
    axs[1, j].axhline(0, color=INK2, lw=1.0)
    for c in [c for c in pav if c["lam"] == lamv]:
        sname = session[(int(c["lam"]), int(c["T"]))]
        axs[0, j].errorbar(c["T"], c["n"], yerr=c["u_rel"], fmt=SMK[sname], ms=5, color=INK, mfc="white" if sname == "A" else INK, elinewidth=0.9, capsize=0)
        axs[1, j].errorbar(c["T"], c["dev"] * 1e4, yerr=c["u_rel"] * 1e4, fmt=SMK[sname], ms=5, color=INK, mfc="white" if sname == "A" else INK, elinewidth=0.9, capsize=0)
    for sname in sorted({session[(int(c["lam"]), int(c["T"]))] for c in pav if c["lam"] == lamv}):
        axs[0, j].plot([], [], SMK[sname], color=INK, mfc="white" if sname == "A" else INK, label=f"session {sname}")
    axs[0, j].set_title(f"{lamv} nm (TE/TM average, bias-corrected)", loc="left")
    axs[0, j].legend(loc="lower left")
    axs[1, j].set_xlabel("temperature (°C)")
    axs[1, j].set_ylim(-18, 10)
axs[0, 0].set_ylabel("$n$"); axs[1, 0].set_ylabel("$n-n_{\\mathrm{IAPWS}}$ ($10^{-4}$)")
fig.align_ylabels(axs[:, 0])
save(fig, "fig7_temperature")
