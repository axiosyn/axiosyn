"""Step 16: figure figS4_dong_fit - one Intralipid scan per wavelength (TM, slow #01) over the whole scan,
fitted with Dong et al.'s model as published (AM), with Dong's model plus a diffuse floor (AM_floor),
and with our model (OURS); residuals below."""
import csv, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import step5_turbid as S5
import step14_dong_model as D

HERE = os.path.dirname(os.path.abspath(__file__))
RES, FIG = os.path.join(HERE, "results"), os.path.join(HERE, "figures")
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e4e3df"
COL = {"AM": "#eb6834", "AM_floor": "#2a78d6", "OURS": INK}
LAB = {"AM": "Dong et al., as published", "AM_floor": "Dong et al. + diffuse floor", "OURS": "this work (Fresnel + floor)"}
plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5, "legend.fontsize": 7.2,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
    "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "savefig.dpi": 300, "legend.frameon": False, "font.family": "DejaVu Sans"})
scans = list(csv.DictReader(open(os.path.join(RES, "turbid_scans.csv"), encoding="utf-8")))
fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.4), sharex="col", gridspec_kw={"height_ratios": [2.2, 1]})
for j, lam in enumerate((532, 964, 1551)):
    r = next(s for s in scans if s["sample"] == "intralipid" and s["method"] == "slow" and int(s["lam"]) == lam
             and s["pol"] == "TM" and int(s["num"]) == 1)
    folder = os.path.join(S5.ROOT, r["folder"])
    med, air = S5.load(os.path.join(folder, r["file"])), S5.load(os.path.join(folder, r["air"]))
    R = med["I"] / np.interp(med["theta"], air["theta"], air["I"], left=np.nan, right=np.nan)
    R *= float(r["Rc_renorm"]) / float(r["Rc"])
    thc, n_p, dth, n0 = float(r["theta_c"]), float(r["n_prism"]), float(r["dth_rot"]), float(r["n_renorm"])
    ok = np.isfinite(R)
    th, y = med["theta"][ok][::3], R[ok][::3]
    x = th - thc
    axs[0, j].plot(x, y, color=MUTED, lw=2.0, alpha=0.6, label="measured")
    for nm in ("AM", "AM_floor", "OURS"):
        p, res = D.fit(nm, th, y, "TM", n_p, S5.SIGMA[lam], dth, n0)
        f = D.model(nm, p, th, "TM", n_p, S5.SIGMA[lam], dth)
        rms = float(np.sqrt(np.mean(res ** 2)))
        axs[0, j].plot(x, f, color=COL[nm], lw=1.0, ls="-" if nm != "AM" else "--", label=f"{LAB[nm]} (rms {rms:.3f})")
        axs[1, j].plot(x, y - f, color=COL[nm], lw=0.8, ls="-" if nm != "AM" else "--")
    axs[0, j].set_title(f"({'abc'[j]}) {lam} nm, TM", loc="left")
    axs[0, j].legend(loc="upper left", fontsize=6.0, handlelength=1.6, bbox_to_anchor=(0.0, 0.98))
    axs[1, j].axhline(0, color=INK2, lw=0.6)
    axs[1, j].set_xlabel("θ − θ_c (deg)")
    axs[0, j].set_ylim(0, 1.1); axs[1, j].set_ylim(-0.25, 0.25)
axs[0, 0].set_ylabel("R (air-normalized)"); axs[1, 0].set_ylabel("residual")
fig.tight_layout()
fig.savefig(os.path.join(FIG, "figS4_dong_fit.png"), bbox_inches="tight"); fig.savefig(os.path.join(FIG, "figS4_dong_fit.pdf"), bbox_inches="tight")
print("wrote figS4_dong_fit")
