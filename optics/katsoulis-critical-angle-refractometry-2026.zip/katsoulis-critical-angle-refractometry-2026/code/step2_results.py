"""Step 2: combine scans, infer angular blur / extinction from peak shapes, correct the
derivative-method bias, and derive (i) TE-TM anisotropy, (ii) n(lambda, T), (iii) dn/dT.

Inputs : results/scans.csv (step1)
Outputs: results/groups.csv, results/blur_inference.csv, results/n_corrected.csv,
         results/anisotropy.csv, results/thermo.csv, results/summary.json
"""
import csv
import json
import math
import os
import sys
from collections import defaultdict

import numpy as np

import water_lib as W

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")

scans = list(csv.DictReader(open(os.path.join(OUT, "scans.csv"), encoding="utf-8")))
for s in scans:
    for k in ("lam", "rep"):
        s[k] = int(s[k])
    for k in ("T", "n_w9", "n_w15", "n_w21", "fwhm", "asym", "Rc_rel", "step", "n_prism", "theta_c"):
        s[k] = float(s[k])

# ------------------------------------------------------------ 1. groups per direction
def stats(v):
    v = np.asarray(v, float)
    sd = v.std(ddof=1) if len(v) > 1 else float("nan")
    return v.mean(), sd, sd / math.sqrt(len(v)) if len(v) > 1 else float("nan"), len(v)

G = defaultdict(list)
for s in scans:
    G[(s["lam"], s["T"], s["pol"], s["direction"])].append(s)

groups = []
for (lam, T, pol, d), v in sorted(G.items()):
    m, sd, se, N = stats([x["n_w15"] for x in v])
    groups.append(dict(lam=lam, T=T, pol=pol, direction=d, N=N, n_mean=m, n_sd=sd, n_sem=se,
                       n_w9=np.mean([x["n_w9"] for x in v]), n_w21=np.mean([x["n_w21"] for x in v]),
                       fwhm=np.median([x["fwhm"] for x in v]), asym=np.median([x["asym"] for x in v]),
                       Rc_rel=np.median([x["Rc_rel"] for x in v]), n_prism=v[0]["n_prism"]))

# a lone TM scan at 633 nm / 52 C and two TE scans at 50 C were one run; keep header temperatures.

# ------------------------------------------------------------ 2. combine rotation directions
C = {}
for g in groups:
    C.setdefault((g["lam"], g["T"], g["pol"]), {})[g["direction"]] = g

combined = []
for (lam, T, pol), dd in sorted(C.items()):
    if "L" in dd and "R" in dd:
        L, R = dd["L"], dd["R"]
        n = 0.5 * (L["n_mean"] + R["n_mean"])
        u = 0.5 * math.sqrt(L["n_sem"] ** 2 + R["n_sem"] ** 2)
        lag = 0.5 * (L["n_mean"] - R["n_mean"])
        N = L["N"] + R["N"]
        nw = {w: 0.5 * (L[f"n_w{w}"] + R[f"n_w{w}"]) for w in (9, 21)}
        mode = "L/R mean"
    else:
        g = dd.get("?") or dd.get("L") or dd.get("R")
        n, u, lag, N = g["n_mean"], g["n_sem"], float("nan"), g["N"]
        if not np.isfinite(u):           # single scan: use L/R half-gap as uncertainty
            u = 5.2e-4
        nw = {w: g[f"n_w{w}"] for w in (9, 21)}
        mode = "mixed/unknown direction"
    allv = [x for x in scans if x["lam"] == lam and x["T"] == T and x["pol"] == pol]
    combined.append(dict(lam=lam, T=T, pol=pol, N=N, mode=mode, n_sdm=n, u_stat=u, lag=lag,
                         n_w9=nw[9], n_w21=nw[21],
                         fwhm=np.median([x["fwhm"] for x in allv]), fwhm_sem=np.std([x["fwhm"] for x in allv], ddof=1) / math.sqrt(len(allv)) if len(allv) > 1 else 0.01,
                         asym=np.median([x["asym"] for x in allv]), asym_sem=np.std([x["asym"] for x in allv], ddof=1) / math.sqrt(len(allv)) if len(allv) > 1 else 0.01,
                         Rc=np.median([x["Rc_rel"] for x in allv]), Rc_sem=np.std([x["Rc_rel"] for x in allv], ddof=1) / math.sqrt(len(allv)) if len(allv) > 1 else 0.02,
                         step=np.median([x["step"] for x in allv]), n_prism=allv[0]["n_prism"]))

# ------------------------------------------------------------ 3. blur / extinction inference
SIG = np.arange(0.004, 0.0701, 0.002)
LOGK = np.arange(-9.0, -2.99, 0.25)
FLOOR = dict(fwhm=0.006, asym=0.008, Rc=0.012)   # model/quantisation floors

def infer(lam, T, kernel="gauss"):
    te = next(c for c in combined if c["lam"] == lam and c["T"] == T and c["pol"] == "TE")
    tm = next(c for c in combined if c["lam"] == lam and c["T"] == T and c["pol"] == "TM")
    n0 = 0.5 * (te["n_sdm"] + tm["n_sdm"]) + 5e-4
    chi = np.zeros((len(SIG), len(LOGK)))
    bte = np.zeros_like(chi)
    btm = np.zeros_like(chi)
    for i, sg in enumerate(SIG):
        for j, lk in enumerate(LOGK):
            c2 = 0.0
            for obs, b in ((te, bte), (tm, btm)):
                r = W.simulate_sdm(obs["pol"], n0, 10 ** lk, obs["n_prism"], sg, obs["step"], kernel=kernel)
                b[i, j] = r["bias"]
                for q, rq in (("fwhm", "fwhm"), ("asym", "asym"), ("Rc", "Rc_rel")):
                    u2 = obs[f"{q}_sem"] ** 2 + FLOOR[q] ** 2
                    c2 += (r[rq] - obs[q]) ** 2 / u2
            chi[i, j] = c2
    w = np.exp(-0.5 * (chi - chi.min()))
    w /= w.sum()
    def wm(a):
        m = float((w * a).sum())
        return m, float(math.sqrt(max((w * (a - m) ** 2).sum(), 0)))
    i0, j0 = np.unravel_index(np.argmin(chi), chi.shape)
    out = dict(lam=lam, T=T, kernel=kernel, chi2_min=float(chi.min()), dof=4,
               sigma_best=float(SIG[i0]), logk_best=float(LOGK[j0]))
    out["sigma"], out["sigma_u"] = wm(SIG[:, None] * np.ones_like(chi))
    out["logk"], out["logk_u"] = wm(LOGK[None, :] * np.ones_like(chi))
    out["bias_TE"], out["bias_TE_u"] = wm(bte)
    out["bias_TM"], out["bias_TM_u"] = wm(btm)
    out["dbias"], out["dbias_u"] = wm(btm - bte)
    # marginal posterior on log k (for extinction estimate)
    out["logk_post"] = [float(x) for x in w.sum(axis=0)]
    return out

conds = sorted({(c["lam"], c["T"]) for c in combined
                if any(d["lam"] == c["lam"] and d["T"] == c["T"] and d["pol"] == "TE" for d in combined)
                and any(d["lam"] == c["lam"] and d["T"] == c["T"] and d["pol"] == "TM" for d in combined)})
inf = {}
for lam, T in conds:
    a = infer(lam, T, "gauss")
    b = infer(lam, T, "box")
    a["dbias_box"], a["bias_TE_box"], a["bias_TM_box"] = b["dbias"], b["bias_TE"], b["bias_TM"]
    a["chi2_box"] = b["chi2_min"]
    inf[(lam, T)] = a
    print(f"{lam:5d} nm {T:4.0f} C: sigma={a['sigma']:.4f}±{a['sigma_u']:.4f} deg, log k={a['logk']:.2f}±{a['logk_u']:.2f}, "
          f"chi2={a['chi2_min']:.1f} (box {b['chi2_min']:.1f}); bias TE={a['bias_TE']*1e5:+.1f}, TM={a['bias_TM']*1e5:+.1f}, "
          f"TM-TE={a['dbias']*1e5:+.2f}±{a['dbias_u']*1e5:.2f} (box {b['dbias']*1e5:+.2f}) e-5")

# 633 nm / 50 C TE and 52 C TM are one run at ~50 C; borrow blur from 633/50 TE if needed
def get_inf(lam, T):
    if (lam, T) in inf:
        return inf[(lam, T)]
    same = [v for (l, t), v in inf.items() if l == lam]
    return min(same, key=lambda v: abs(v["T"] - T))

# ------------------------------------------------------------ 4. corrected indices
ncor = []
for c in combined:
    a = get_inf(c["lam"], c["T"])
    b, bu = a[f"bias_{c['pol']}"], a[f"bias_{c['pol']}_u"]
    b_sys = abs(a[f"bias_{c['pol']}_box"] - b)                 # blur-shape systematic
    n = c["n_sdm"] - b
    u_bias = math.sqrt(bu ** 2 + b_sys ** 2)
    ncor.append(dict(c, bias=b, u_bias=u_bias, n_cor=n, u_rel=math.sqrt(c["u_stat"] ** 2 + u_bias ** 2),
                     n_iapws_air=float(W.n_iapws_rel_air(c["lam"], c["T"])),
                     n_iapws_vac=float(W.n_iapws_vac(c["lam"], c["T"]))))

# ------------------------------------------------------------ 5. anisotropy TM - TE
aniso = []
for lam, T in conds:
    te = next(c for c in ncor if c["lam"] == lam and c["T"] == T and c["pol"] == "TE")
    tm = next(c for c in ncor if c["lam"] == lam and c["T"] == T and c["pol"] == "TM")
    a = inf[(lam, T)]
    d_meas = tm["n_sdm"] - te["n_sdm"]
    u_meas = math.sqrt(te["u_stat"] ** 2 + tm["u_stat"] ** 2)
    d_sys = abs(a["dbias_box"] - a["dbias"])
    u_model = math.sqrt(a["dbias_u"] ** 2 + d_sys ** 2)
    d_cor = d_meas - a["dbias"]
    # per-direction measured gaps (consistency check)
    dirs = {}
    for d in ("L", "R"):
        gte = [g for g in groups if g["lam"] == lam and g["T"] == T and g["pol"] == "TE" and g["direction"] == d]
        gtm = [g for g in groups if g["lam"] == lam and g["T"] == T and g["pol"] == "TM" and g["direction"] == d]
        if gte and gtm:
            dirs[d] = gtm[0]["n_mean"] - gte[0]["n_mean"]
    aniso.append(dict(lam=lam, T=T, d_meas=d_meas, u_meas=u_meas, d_pred=a["dbias"], u_pred=u_model,
                      d_cor=d_cor, u_cor=math.sqrt(u_meas ** 2 + u_model ** 2),
                      d_L=dirs.get("L", float("nan")), d_R=dirs.get("R", float("nan")),
                      d_w9=tm["n_w9"] - te["n_w9"], d_w21=tm["n_w21"] - te["n_w21"]))

wts = np.array([1 / x["u_cor"] ** 2 for x in aniso])
dc = np.array([x["d_cor"] for x in aniso])
wmean = float((wts * dc).sum() / wts.sum())
wmean_u = float(1 / math.sqrt(wts.sum()))
chi2_aniso = float((wts * (dc - wmean) ** 2).sum())
dm = np.array([x["d_meas"] for x in aniso]); wm_ = np.array([1 / x["u_meas"] ** 2 for x in aniso])
raw_mean = float((wm_ * dm).sum() / wm_.sum()); raw_u = float(1 / math.sqrt(wm_.sum()))
print(f"\nRaw TM-TE (weighted): {raw_mean*1e5:+.2f} ± {raw_u*1e5:.2f} e-5")
print(f"Corrected TM-TE (weighted over {len(aniso)} conditions): {wmean*1e5:+.2f} ± {wmean_u*1e5:.2f} e-5, chi2={chi2_aniso:.1f}/{len(aniso)-1}")

# ------------------------------------------------------------ 6. polarization-averaged n, thermo-optics
pav = []
for lam, T in sorted({(c["lam"], c["T"]) for c in ncor}):
    v = [c for c in ncor if c["lam"] == lam and c["T"] == T]
    if len(v) == 2:
        n = 0.5 * (v[0]["n_cor"] + v[1]["n_cor"])
        u = 0.5 * math.sqrt(v[0]["u_stat"] ** 2 + v[1]["u_stat"] ** 2)
        ub = 0.5 * (v[0]["u_bias"] + v[1]["u_bias"])      # bias errors are correlated between pols
        u = math.sqrt(u ** 2 + ub ** 2)
    else:
        n, u = v[0]["n_cor"], v[0]["u_rel"]
    pav.append(dict(lam=lam, T=T, n=n, u_rel=u, n_iapws_air=float(W.n_iapws_rel_air(lam, T)),
                    dev=n - float(W.n_iapws_rel_air(lam, T))))

thermo = []
for lam in (532, 633):
    v = sorted([p for p in pav if p["lam"] == lam], key=lambda p: p["T"])
    T = np.array([p["T"] for p in v]); n = np.array([p["n"] for p in v]); u = np.array([p["u_rel"] for p in v])
    # quadratic in (T-25) when >=3 temperatures, weighted
    deg = 2 if len(T) >= 4 else 1
    A = np.vstack([(T - 25) ** k for k in range(deg + 1)]).T
    Wt = np.diag(1 / u ** 2)
    cov = np.linalg.inv(A.T @ Wt @ A)
    p = cov @ A.T @ Wt @ n
    res = n - A @ p
    chi2 = float(res @ Wt @ res)
    # slope between 25 and 70 C (both directions measured at both)
    n25 = next(q for q in v if q["T"] == 25); n70 = next(q for q in v if q["T"] == 70)
    s2570 = (n70["n"] - n25["n"]) / 45
    s2570_u = math.hypot(n70["u_rel"], n25["u_rel"]) / 45
    ia = (float(W.n_iapws_rel_air(lam, 70)) - float(W.n_iapws_rel_air(lam, 25))) / 45
    thermo.append(dict(lam=lam, temps=[float(t) for t in T], deg=deg, coef=[float(x) for x in p],
                       coef_u=[float(math.sqrt(cov[k, k])) for k in range(deg + 1)], chi2=chi2,
                       slope_25_70=s2570, slope_25_70_u=s2570_u, slope_iapws=ia,
                       dndT_25=float(p[1]), dndT_25_u=float(math.sqrt(cov[1, 1])),
                       dndT_25_iapws=float((W.n_iapws_rel_air(lam, 25.5) - W.n_iapws_rel_air(lam, 24.5)))))
    print(f"{lam} nm: (n70-n25)/45 = {s2570*1e5:.2f} ± {s2570_u*1e5:.2f} e-5/K ; IAPWS {ia*1e5:.2f} e-5/K ; poly fit deg {deg}: {[f'{x:.4e}' for x in p]} chi2={chi2:.1f}")

# ------------------------------------------------------------ 7. write outputs
def dump(name, rows):
    rows = [{k: v for k, v in r.items() if not isinstance(v, list)} for r in rows]
    with open(os.path.join(OUT, name), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

dump("groups.csv", groups)
dump("blur_inference.csv", list(inf.values()))
dump("n_corrected.csv", ncor)
dump("anisotropy.csv", aniso)
dump("n_pol_avg.csv", pav)
json.dump(dict(raw_TM_minus_TE=raw_mean, raw_TM_minus_TE_u=raw_u,
               corrected_TM_minus_TE=wmean, corrected_TM_minus_TE_u=wmean_u, chi2=chi2_aniso,
               ndof=len(aniso) - 1, thermo=thermo,
               logk_grid=[float(x) for x in LOGK],
               logk_post={f"{k[0]}_{k[1]:.0f}": v["logk_post"] for k, v in inf.items()}),
          open(os.path.join(OUT, "summary.json"), "w"), indent=1)

print("\nCorrected n (relative to air) vs IAPWS:")
for c in ncor:
    print(f"{c['lam']:5d} {c['T']:4.0f} {c['pol']}  N={c['N']:2d} {c['mode']:24s} sdm={c['n_sdm']:.6f} bias={c['bias']*1e5:+6.1f}e-5 "
          f"n={c['n_cor']:.6f}±{c['u_rel']:.6f}  lag={c['lag']*1e4 if np.isfinite(c['lag']) else float('nan'):+.2f}e-4  "
          f"IAPWS(air)={c['n_iapws_air']:.6f}  dev={(c['n_cor']-c['n_iapws_air'])*1e4:+.2f}e-4")
print("\nAnisotropy per condition (e-5):")
for a in aniso:
    print(f"{a['lam']:5d} {a['T']:4.0f}  meas={a['d_meas']*1e5:+6.2f}±{a['u_meas']*1e5:.2f}  (L {a['d_L']*1e5:+.2f}, R {a['d_R']*1e5:+.2f}; w9 {a['d_w9']*1e5:+.2f}, w21 {a['d_w21']*1e5:+.2f})"
          f"  pred={a['d_pred']*1e5:+.2f}±{a['u_pred']*1e5:.2f}  corrected={a['d_cor']*1e5:+.2f}±{a['u_cor']*1e5:.2f}")
