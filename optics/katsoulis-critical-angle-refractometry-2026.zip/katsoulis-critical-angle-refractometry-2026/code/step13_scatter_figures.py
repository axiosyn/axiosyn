"""Step 13: figures for the scattering paper.
figS2_edge_fit : measured Intralipid profile, edge-shape fit (with diffuse floor) and Fresnel-only fit, 532 and 1551 nm
figS3_mus      : mu_s vs wavelength, floor-corrected, with independent- and dependent-scattering predictions
"""
import csv
import math
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import water_lib as W
import step5_turbid as S5
import step9_scatter_fit as S9
import step12_compare_DS as S12

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES, FIG = os.path.join(HERE, "results"), os.path.join(HERE, "figures")
INK, INK2, MUTED, GRID, ACC = "#0b0b0b", "#52514e", "#8a8984", "#e4e3df", "#2a78d6"
plt.rcParams.update({
    "font.size": 8.5, "axes.labelsize": 8.5, "axes.titlesize": 9, "legend.fontsize": 7.2, "xtick.labelsize": 7.5,
    "ytick.labelsize": 7.5, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False, "axes.spines.right": False,
    "savefig.dpi": 300, "legend.frameon": False, "font.family": "DejaVu Sans"})

# ---------------------------------------------------------------- figure S2: edge fits
scans = list(csv.DictReader(open(os.path.join(RES, "turbid_scans.csv"), encoding="utf-8")))
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.1), sharey=True)
for ax, lam, title in zip(axs, (532, 1551), ("(a) 532 nm, TM", "(b) 1551 nm, TM")):
    r = next(s for s in scans if s["sample"] == "intralipid" and s["method"] == "slow" and int(s["lam"]) == lam
             and s["pol"] == "TM" and int(s["num"]) == 1)
    folder = os.path.join(S5.ROOT, r["folder"])
    med, air = S5.load(os.path.join(folder, r["file"])), S5.load(os.path.join(folder, r["air"]))
    R = med["I"] / np.interp(med["theta"], air["theta"], air["I"], left=np.nan, right=np.nan)
    thc = float(r["theta_c"]); n_p, dth = float(r["n_prism"]), float(r["dth_rot"])
    m = np.isfinite(R) & (med["theta"] > thc - 2) & (med["theta"] < thc + 2)
    th, Rm = med["theta"][m], R[m]
    f = S9.fit_profile(th, Rm, "TM", n_p, S5.SIGMA[lam], dth, float(r["n_renorm"]), float(r["k_renorm"]), True)
    g = S9.fit_profile(th, Rm, "TM", n_p, S5.SIGMA[lam], dth, float(r["n_renorm"]), float(r["k_renorm"]), False)
    coh = W.blurred_R(th + dth, (f["n"] + 1j * f["k"]) / n_p, "TM", S5.SIGMA[lam])
    coh0 = W.blurred_R(th + dth, (g["n"] + 1j * g["k"]) / n_p, "TM", S5.SIGMA[lam])
    x = th - thc
    ax.plot(x, Rm, color=MUTED, lw=2.2, alpha=0.6, label="measured R(θ)")
    ax.plot(x, f["a"] + f["b"] * coh, color=ACC, lw=1.3, label=f"fit with diffuse floor (k = {f['k']:.1e})")
    ax.plot(x, f["b"] * coh, color=ACC, lw=0.9, ls="--", label="its coherent part b·R_coh")
    ax.plot(x, g["b"] * coh0, color=INK, lw=0.9, ls=":", label=f"Fresnel fit without floor (k = {g['k']:.1e})")
    ax.axhline(f["a"], color=INK2, lw=0.6, ls="-.")
    ax.text(0.3, f["a"] - 0.055, f"diffuse floor a = {f['a']:.2f}", fontsize=7, color=INK2)
    ax.set_title(title, loc="left"); ax.set_xlabel("θ − θ_c (deg)"); ax.set_xlim(-2, 2)
axs[0].set_ylabel("R (air-normalized)"); axs[0].set_ylim(0, 1.1)
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, ["measured R(θ)", "fit with diffuse floor", "its coherent part b·R_coh", "Fresnel fit without floor"],
           loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.03))
fig.tight_layout(rect=(0, 0.08, 1, 1))
fig.savefig(os.path.join(FIG, "figS2_edge_fit.png"), bbox_inches="tight"); fig.savefig(os.path.join(FIG, "figS2_edge_fit.pdf"), bbox_inches="tight")
print("wrote figS2_edge_fit")

# ---------------------------------------------------------------- figure S3: mu_s vs lambda
rows = list(csv.DictReader(open(os.path.join(RES, "scatter_vs_DS.csv"), encoding="utf-8")))
lam = np.array([float(r["lam"]) for r in rows]); mus = np.array([float(r["mu_s"]) for r in rows])
u = np.array([float(r["mu_s_u"]) for r in rows]); unc = np.array([float(r["mu_s_uncorrected"]) for r in rows])
gl = np.geomspace(480, 1700, 200)
fig, ax = plt.subplots(figsize=(3.6, 3.9))
ax.plot(gl, [S12.is_att(v) for v in gl], color=MUTED, lw=1.5, label="independent scattering [3]")
ax.plot(gl, [S12.is_att(v) * S12.packing(v) for v in gl], color=ACC, lw=1.5, label="dependent scattering, φ = 0.227 [3]")
ax.plot(lam * 1.03, unc, "o", ms=4.5, mfc="white", mec=INK2, mew=0.9, label="this work, before floor correction")
lo = np.minimum(u, mus * 0.95)          # keep the log-axis error bar above zero
ax.errorbar(lam, mus, yerr=[lo, u], fmt="D", ms=5.5, color=INK, mfc=INK, capsize=3, lw=1.1, label="this work, corrected ± u", zorder=5)
for x, y, r in zip(lam, mus, rows):
    ax.annotate(f"×{float(r['ratio_DS']):.2f}", (x, y), xytext=(7, -2), textcoords="offset points", fontsize=7, color=INK2)
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xticks([500, 700, 1000, 1500]); ax.set_xticklabels(["500", "700", "1000", "1500"]); ax.minorticks_off()
ax.set_ylim(0.6, 300)
ax.set_xlabel("wavelength (nm)"); ax.set_ylabel("scattering coefficient $\\mu_s$ (mm$^{-1}$)")
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=1, fontsize=6.8)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "figS3_mus.png"), bbox_inches="tight"); fig.savefig(os.path.join(FIG, "figS3_mus.pdf"), bbox_inches="tight")
print("wrote figS3_mus")
