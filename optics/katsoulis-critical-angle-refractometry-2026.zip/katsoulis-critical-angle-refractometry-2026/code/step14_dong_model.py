"""Step 14: fit the Intralipid scans with the angle-dependent model (AM) of Dong et al.,
J. Biomed. Opt. 18, 087003 (2013), and compare it with plain Fresnel theory and with our model.

Dong et al., Eqs. (1)-(2): Fresnel reflectance of a medium with index n_r + i n_i(theta), where
    n_i(theta) = n_i                     below the transition angle theta_t (non-TIR side)
    n_i(theta) = n_i * kappa(theta)      above it (TIR side)
    kappa      = [4 pi n_prism sqrt((M - L)/2)]^-1 = 1 / (4 pi n_prism Im w),
    w          = sqrt((n_r + i n_i)^2 / n_prism^2 - sin^2 theta)        (kappa built from the constant n_i)
theta_t starts where L = Re(w^2) changes sign and is optimized with n_r and n_i. They fit the whole curve with
these three numbers only (their paper counts n_r and n_i as the fit parameters).

Models fitted to each air-normalized scan (plateau re-normalization of step 5 applied, rotation offset applied):
  F        Fresnel, constant n_i                                   [n, log k]
  AM       Dong et al.                                             [n, log k, theta_t]
  AM_blur  Dong et al. convolved with the water-derived angular spread sigma   [n, log k, theta_t]
  OURS     a + b * blurred Fresnel (step 9)                        [n, log k, a, b]
  AM_floor a + b * AM_blur: Dong et al. plus the same diffuse floor  [n, log k, theta_t, a, b]
Fit ranges: 'full' = whole scan (about -7 to +4 deg around theta_c), and 'edge' = theta_c +- 2 deg.
Output: results/dong_fits.csv
"""
import csv
import math
import os
import sys

import numpy as np
from scipy.optimize import least_squares
from scipy.signal import fftconvolve

import water_lib as W
import step5_turbid as S5

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
FINE = 0.001   # deg, model grid


def kappa(theta, nr, ni, n_p):
    s2 = np.sin(np.radians(theta)) ** 2
    w = np.sqrt(((nr + 1j * ni) / n_p) ** 2 - s2 + 0j)
    return 1.0 / (4 * math.pi * n_p * np.abs(w.imag))


def theta_L(nr, ni, n_p):
    """angle where L = (nr^2 - ni^2)/n_p^2 - sin^2 theta changes sign"""
    return math.degrees(math.asin(min(math.sqrt(nr * nr - ni * ni) / n_p, 0.9999)))


def R_am(theta, nr, ni, n_p, pol, th_t):
    ni_eff = np.where(theta > th_t, ni * kappa(theta, nr, ni, n_p), ni)
    return W.fresnel_R(theta, (nr + 1j * ni_eff) / n_p, pol)


def blur(theta, fn, sigma):
    g = np.arange(theta.min() - 6 * sigma - 0.05, theta.max() + 6 * sigma + 0.05, FINE)
    R = fn(g)
    x = np.arange(-6 * sigma, 6 * sigma + FINE / 2, FINE)
    ker = np.exp(-0.5 * (x / sigma) ** 2); ker /= ker.sum()
    h = len(x) // 2
    Rb = fftconvolve(np.pad(R, h, mode="edge"), ker, mode="valid")[: len(g)]
    return np.interp(theta, g, Rb)


def model(name, p, th, pol, n_p, sigma, dth):
    t = th + dth
    if name == "F":
        n, lk = p
        return W.fresnel_R(t, (n + 1j * 10 ** lk) / n_p, pol)
    if name in ("AM", "AM_blur"):
        n, lk, dt = p
        ni = 10 ** lk
        tt = theta_L(n, ni, n_p) + dt
        f = lambda x: R_am(x, n, ni, n_p, pol, tt)
        return f(t) if name == "AM" else blur(t, f, sigma)
    if name == "OURS":
        n, lk, a, b = p
        return a + b * W.blurred_R(t, (n + 1j * 10 ** lk) / n_p, pol, sigma)
    if name == "AM_floor":
        n, lk, dt, a, b = p
        ni = 10 ** lk
        tt = theta_L(n, ni, n_p) + dt
        return a + b * blur(t, lambda x: R_am(x, n, ni, n_p, pol, tt), sigma)
    raise ValueError(name)


def fit(name, th, R, pol, n_p, sigma, dth, n0):
    starts = {"F": [[n0, lk] for lk in (-3.5, -3.0, -2.5, -2.0)],
              "AM": [[n0, lk, dt] for lk in (-3.5, -3.0, -2.5, -2.0) for dt in (-0.1, 0.0, 0.1)],
              "OURS": [[n0, lk, 0.1, 0.9] for lk in (-3.5, -3.0, -2.5, -2.0)],
              "AM_floor": [[n0, lk, dt, 0.1, 0.9] for lk in (-3.5, -3.0, -2.5, -2.0) for dt in (-0.1, 0.1)]}
    starts["AM_blur"] = starts["AM"]
    lo = {"F": [n0 - 0.03, -6], "AM": [n0 - 0.03, -6, -0.6], "OURS": [n0 - 0.03, -6, -0.2, 0.5], "AM_floor": [n0 - 0.03, -6, -0.6, -0.2, 0.5]}
    hi = {"F": [n0 + 0.03, -0.7], "AM": [n0 + 0.03, -0.7, 0.6], "OURS": [n0 + 0.03, -0.7, 0.6, 1.5], "AM_floor": [n0 + 0.03, -0.7, 0.6, 0.6, 1.5]}
    lo["AM_blur"], hi["AM_blur"] = lo["AM"], hi["AM"]
    best = None
    for x0 in starts[name]:
        r = least_squares(lambda p: model(name, p, th, pol, n_p, sigma, dth) - R, x0, bounds=(lo[name], hi[name]),
                          diff_step=1e-4)
        if best is None or r.cost < best.cost:
            best = r
    return best.x, best.fun


def main(only=None):
    scans = [r for r in csv.DictReader(open(os.path.join(RES, "turbid_scans.csv"), encoding="utf-8"))
             if r["sample"] == "intralipid"]
    if only:
        scans = scans[:only]
    rows = []
    for r in scans:
        lam, pol = int(r["lam"]), r["pol"]
        folder = os.path.join(S5.ROOT, r["folder"])
        med, air = S5.load(os.path.join(folder, r["file"])), S5.load(os.path.join(folder, r["air"]))
        R = med["I"] / np.interp(med["theta"], air["theta"], air["I"], left=np.nan, right=np.nan)
        R = R * float(r["Rc_renorm"]) / float(r["Rc"])        # plateau re-normalization (step 5)
        thc, n_p, dth, n0 = float(r["theta_c"]), float(r["n_prism"]), float(r["dth_rot"]), float(r["n_renorm"])
        ok = np.isfinite(R)
        out = dict(lam=lam, pol=pol, method=r["method"], num=int(r["num"]))
        for rng, (a, b) in (("full", (-99, 99)), ("edge", (-2, 2))):
            m = ok & (med["theta"] > thc + a) & (med["theta"] < thc + b)
            th, y = med["theta"][m], R[m]
            # sample the full range every 3rd point to keep the fits fast (still ~1000 points, as in Dong et al.)
            if rng == "full":
                th, y = th[::3], y[::3]
            edge = np.abs(th - thc) < 2
            for name in ("F", "AM", "AM_blur", "OURS", "AM_floor"):
                p, res = fit(name, th, y, pol, n_p, S5.SIGMA[lam], dth, n0)
                out[f"{name}_{rng}_n"] = p[0]
                out[f"{name}_{rng}_k"] = 10 ** p[1]
                out[f"{name}_{rng}_rms"] = float(np.sqrt(np.mean(res ** 2)))
                out[f"{name}_{rng}_rms_edge"] = float(np.sqrt(np.mean(res[edge] ** 2)))
                out[f"{name}_{rng}_rms_below"] = float(np.sqrt(np.mean(res[th < thc - 2] ** 2))) if np.any(th < thc - 2) else float("nan")
                if name.startswith("AM"):
                    out[f"{name}_{rng}_dt"] = p[2]
                if name == "OURS":
                    out[f"{name}_{rng}_a"], out[f"{name}_{rng}_b"] = p[2], p[3]
                if name == "AM_floor":
                    out[f"{name}_{rng}_a"], out[f"{name}_{rng}_b"] = p[3], p[4]
        rows.append(out)
        print(f"{lam:5d} {pol} {r['method']:4s} #{int(r['num']):02d} full: " +
              "  ".join(f"{nm} k={out[nm + '_full_k']:.2e} rms={out[nm + '_full_rms']:.4f}" for nm in ("F", "AM", "AM_blur", "OURS", "AM_floor")),
              flush=True)
    with open(os.path.join(RES, "dong_fits.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

    print("\nmedians per wavelength / polarization (full-range fits; rms over the full range | edge +-2 deg | below -2 deg)")
    for lam in (532, 964, 1551):
        for pol in ("TE", "TM"):
            s = [x for x in rows if x["lam"] == lam and x["pol"] == pol]
            if not s:
                continue
            md = lambda k: float(np.median([x[k] for x in s]))
            print(f"{lam} {pol} N={len(s)}: " + " | ".join(
                f"{nm}: k={md(nm + '_full_k'):.2e} n={md(nm + '_full_n'):.4f} rms={md(nm + '_full_rms'):.4f}/{md(nm + '_full_rms_edge'):.4f}/{md(nm + '_full_rms_below'):.4f}"
                for nm in ("F", "AM", "AM_blur", "OURS", "AM_floor")))


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else None)
