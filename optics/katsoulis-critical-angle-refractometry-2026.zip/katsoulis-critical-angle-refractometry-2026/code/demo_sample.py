"""Run the analysis on the 16 sample files shipped in ../data_sample and compare with the papers.

    python demo_sample.py

Water: derivative-method index per scan, the L/R rotation offset, and the bias-corrected index
       (bias from results/blur_inference.csv), next to the value reported from the full dataset.
Intralipid / cream: air-normalized reflectance -> plain derivative method, ideal extended
       derivative method and instrument-corrected EDM, next to the paper's group means.
Single scans scatter around the full-dataset means by roughly the scan-to-scan spread given in the papers.
"""
import csv
import glob
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding="utf-8")

import water_lib as W          # noqa: E402
import step5_turbid as T       # noqa: E402  (importing does not run the full analysis)

DATA = os.path.join(HERE, "..", "data_sample")
RES = os.path.join(HERE, "results")

def rows(name):
    return list(csv.DictReader(open(os.path.join(RES, name), encoding="utf-8")))

# ------------------------------------------------------------------ water
bias = {(int(r["lam"]), float(r["T"])): r for r in rows("blur_inference.csv")}
paper = {(int(r["lam"]), float(r["T"]), r["pol"]): r for r in rows("n_corrected.csv")}
scans = [W.load_scan(p) for p in sorted(glob.glob(os.path.join(DATA, "water", "*.csv")))]
print("WATER (25 °C)          n_SDM per scan            L-R (1e-4)   corrected n    paper (full data)")
for lam in sorted({s.lam for s in scans}):
    for pol in ("TE", "TM"):
        v = {s.direction: W.sdm_index(s)["n_sdm"] for s in scans if s.lam == lam and s.pol == pol}
        if set(v) != {"L", "R"}:
            continue
        mean = 0.5 * (v["L"] + v["R"])
        corr = mean - float(bias[(lam, 25.0)][f"bias_{pol}"])
        p = paper[(lam, 25.0, pol)]
        print(f"  {lam:4d} nm {pol}   L {v['L']:.5f}  R {v['R']:.5f}   {1e4 * (v['L'] - v['R']):+6.2f}      "
              f"{corr:.5f}      {float(p['n_cor']):.5f} ± {float(p['u_rel']):.5f}")

# ------------------------------------------------------------------ Intralipid and cream
per_pol = rows("turbid_per_pol.csv")
print("\nTURBID MEDIA (single scan)     n_SDM     n_EDM     n_corrected   k (indicative)   paper mean (scan sd)")
for folder, sample in (("intralipid_1551nm", "intralipid"), ("cream_633nm", "cream")):
    for med_path in sorted(glob.glob(os.path.join(DATA, folder, f"{sample}_*.txt"))):
        name = os.path.basename(med_path)
        lam, pol = int(name.split("_")[1]), name.split("_")[2]
        air_path = os.path.join(DATA, folder, name.replace(sample, "air", 1))
        r = T.analyze_pair(T.load(med_path), T.load(air_path), lam, pol)
        ref = [p for p in per_pol if p["sample"] == sample and int(p["lam"]) == lam and p["pol"] == pol and p["method"] == "slow"]
        ref_txt = f"{float(ref[0]['n']):.4f} ({float(ref[0]['sd']):.4f})" if ref else "-"
        print(f"  {sample:10s} {lam:4d} nm {pol}    {r['n_sdm']:.4f}    {r['n_edm']:.4f}    {r['n_renorm']:.4f}       "
              f"{r['k_renorm']:.1e}          {ref_txt}")
print("\nNote: the papers report cream values only as 'not a reliable refractive index' (TE and TM disagree).")
