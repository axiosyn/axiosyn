"""Analysis library for the polarization-resolved critical-angle refractometry of water.

Raw files: Metricon prism-coupler exports (one scan per file), columns
TablePos, ExtAngle, IntAngle [deg], Beta (= n_prism(T) * sin IntAngle), I [counts], %I, Smooth %I.
Header line: name, '', '', '', timestamp, 'TempCo: x' (prism dn/dT in 1e-5/K), 'Temp: T' (deg C).

File naming: water_<lambda nm>_<T C>_<TE|TM>_<repeat>[_<L|R>].{csv,dat}
L / R = direction in which the rotary table was turning during the scan.
"""
from __future__ import annotations

import csv
import math
import os
import re
from dataclasses import dataclass, field
from datetime import datetime

import numpy as np
from scipy.optimize import least_squares
from scipy.signal import savgol_filter

# --------------------------------------------------------------------------- I/O

NAME_RE = re.compile(r"water_(\d+)_(\d+)_(T[EM])_(\d+)(?:_([LR]))?\.(csv|dat)$")


@dataclass
class Scan:
    path: str
    lam: int            # nominal wavelength, nm
    T_nominal: int      # from filename
    T: float            # from file header (instrument set point), deg C
    pol: str            # 'TE' or 'TM'
    rep: int
    direction: str      # 'L', 'R' or '?' (direction not recorded)
    internal_name: str
    time: datetime
    tempco: float       # prism dn/dT, 1e-5 / K
    theta: np.ndarray   # internal angle, deg, ascending
    I: np.ndarray       # detector counts
    beta: np.ndarray    # n_prism(T) * sin(theta)
    n_prism: float = field(init=False)

    def __post_init__(self):
        k = len(self.theta) // 2
        self.n_prism = float(self.beta[k] / math.sin(math.radians(self.theta[k])))

    @property
    def label(self):
        return f"{self.lam}_{self.T_nominal}_{self.pol}_{self.rep:03d}_{self.direction}"


def load_scan(path: str) -> Scan:
    m = NAME_RE.search(os.path.basename(path))
    if not m:
        raise ValueError(f"unrecognised file name {path}")
    with open(path, encoding="latin-1") as f:
        lines = f.read().splitlines()
    hdr = next(csv.reader([lines[0]]))
    rows = []
    for line in lines[3:]:
        try:
            rows.append([float(x) for x in line.split(",")])
        except ValueError:
            pass
    d = np.array(rows)
    d = d[np.argsort(d[:, 2])]
    return Scan(
        path=path, lam=int(m[1]), T_nominal=int(m[2]),
        T=float(hdr[6].split(":")[1]), pol=m[3], rep=int(m[4]), direction=m[5] or "?",
        internal_name=hdr[0],
        time=datetime.strptime(" ".join(hdr[4].split()), "%m/%d/%Y %I:%M:%S %p"),
        tempco=float(hdr[5].split(":")[1]),
        theta=d[:, 2], I=d[:, 4], beta=d[:, 3],
    )


def load_all(folder: str) -> list[Scan]:
    out = []
    for fn in sorted(os.listdir(folder)):
        if NAME_RE.search(fn):
            out.append(load_scan(os.path.join(folder, fn)))
    return out


# ------------------------------------------------------------------ references

def rho_water_kell(t_c):
    """Density of air-free water at 0.1 MPa, kg/m^3 (Kell 1975)."""
    t = np.asarray(t_c, float)
    return (999.83952 + 16.945176 * t - 7.9870401e-3 * t**2 - 46.170461e-6 * t**3
            + 105.56302e-9 * t**4 - 280.54253e-12 * t**5) / (1 + 16.879850e-3 * t)


def n_iapws_vac(lam_nm, t_c):
    """IAPWS R9-97 refractive index of liquid water w.r.t. vacuum (0.1 MPa).
    Validated 0.2-1.1 um; 'extrapolation reasonable up to 1.9 um'."""
    a = [0.244257733, 9.74634476e-3, -3.73234996e-3, 2.68678472e-4,
         1.58920570e-3, 2.45934259e-3, 0.900704920, -1.66626219e-2]
    Tb = (np.asarray(t_c, float) + 273.15) / 273.15
    rb = rho_water_kell(t_c) / 1000.0
    lb = (np.asarray(lam_nm, float) / 1000.0) / 0.589
    A = rb * (a[0] + a[1] * rb + a[2] * Tb + a[3] * lb**2 * Tb + a[4] / lb**2
              + a[5] / (lb**2 - 0.2292020**2) + a[6] / (lb**2 - 5.432937**2) + a[7] * rb**2)
    return np.sqrt((1 + 2 * A) / (1 - A))


def n_air(lam_nm):
    """Refractive index of standard dry air, 15 C, 101.325 kPa, 450 ppm CO2
    (Ciddor 1996 simplified as Edlen/Birch-Downs form); lam in nm (vacuum)."""
    s2 = (1000.0 / np.asarray(lam_nm, float)) ** 2  # um^-2
    return 1 + 1e-8 * (5792105 / (238.0185 - s2) + 167917 / (57.362 - s2))


def n_air_lab(lam_nm, t_c=25.0, p_kpa=101.325):
    """Scale standard-air refractivity to lab temperature/pressure (ideal gas)."""
    return 1 + (n_air(lam_nm) - 1) * (p_kpa / 101.325) * (288.15 / (273.15 + t_c))


def n_iapws_rel_air(lam_nm, t_c, t_air=25.0):
    """IAPWS value expressed relative to laboratory air, i.e. on the same
    scale as prism indices quoted relative to air (Metricon convention)."""
    return n_iapws_vac(lam_nm, t_c) / n_air_lab(lam_nm, t_air)


def n_kedenburg_20c(lam_nm):
    """Kedenburg et al., Opt. Mater. Express 2, 1588 (2012); distilled water 20 C, 0.5-1.6 um."""
    l2 = (np.asarray(lam_nm, float) / 1000.0) ** 2
    return np.sqrt(1 + 0.75831 * l2 / (l2 - 0.01007) + 0.08495 * l2 / (l2 - 8.91377))


# Extinction coefficient k of water at 25 C, interpolated from Segelstein (1981) /
# Hale & Querry (1973) tables (refractiveindex.info). Used only for the attenuation term.
K_WATER = {532: 1.5e-9, 633: 1.4e-8, 964: 3.0e-6, 1551: 1.3e-4}


# ------------------------------------------------------------------ Fresnel

def fresnel_R(theta_deg, n_rel, pol):
    """Internal reflectance at a prism/sample interface.
    n_rel = (n + i k)/n_prism (complex); theta = internal incidence angle in the prism."""
    th = np.radians(theta_deg)
    eps = np.asarray(n_rel, complex) ** 2
    c = np.cos(th)
    w = np.sqrt(eps - np.sin(th) ** 2 + 0j)
    w = np.where(w.imag < 0, -w, w)
    if pol == "TE":
        r = (c - w) / (c + w)
    else:
        r = (eps * c - w) / (eps * c + w)
    return np.abs(r) ** 2


def blurred_R(theta_deg, n_rel, pol, sigma_deg, step=2e-4, kernel="gauss"):
    """Fresnel reflectance convolved with an angular spread (beam divergence,
    finite spot, detector aperture), evaluated at theta_deg.
    kernel='gauss': Gaussian of standard deviation sigma_deg;
    kernel='box'  : uniform distribution with the same standard deviation (full width sqrt(12)*sigma)."""
    from scipy.signal import fftconvolve
    lo, hi = theta_deg.min() - 6 * sigma_deg - 0.05, theta_deg.max() + 6 * sigma_deg + 0.05
    g = np.arange(lo, hi, step)
    R = fresnel_R(g, n_rel, pol)
    if sigma_deg > step:
        x = np.arange(-6 * sigma_deg, 6 * sigma_deg + step / 2, step)
        if kernel == "gauss":
            ker = np.exp(-0.5 * (x / sigma_deg) ** 2)
        else:
            ker = (np.abs(x) <= math.sqrt(3) * sigma_deg).astype(float)
        ker /= ker.sum()
        h = len(x) // 2
        Rp = np.pad(R, h, mode="edge")
        R = fftconvolve(Rp, ker, mode="valid")[: len(g)]
    return np.interp(theta_deg, g, R)


# ------------------------------------------------------------------ derivative method

SG_WINDOW = 15   # samples (~0.055 deg); sensitivity tested in run_analysis
SG_ORDER = 2


def derivative_peak(theta, I, window=SG_WINDOW, order=SG_ORDER):
    """Standard derivative method: angle of maximum dI/dtheta.
    Returns (theta_c [deg], derivative array, index of max)."""
    # samples are uniform in table position, nearly uniform in internal angle
    dI = savgol_filter(I, window, order, deriv=1) / np.gradient(theta)
    m = window  # ignore Savitzky-Golay edge artefacts at both ends of the scan
    k = m + int(np.argmax(dI[m:-m]))
    j0, j1 = max(k - 5, 0), min(k + 6, len(theta))
    x, y = theta[j0:j1], dI[j0:j1]
    c = np.polyfit(x - theta[k], y, 2)
    thc = theta[k]
    if c[0] < 0:
        cand = theta[k] - c[1] / (2 * c[0])
        if abs(cand - theta[k]) < 3 * abs(theta[1] - theta[0]):
            thc = cand
    return thc, dI, k


def despike(I, width=5, thresh=6.0):
    """Replace isolated single-sample spikes (|I - running median| > thresh * robust sd)
    by the running median. Leaves the smooth TIR edge untouched."""
    from scipy.signal import medfilt
    m = medfilt(I.astype(float), width)
    r = I - m
    mad = np.median(np.abs(r - np.median(r))) * 1.4826
    mad = max(mad, 1.0)  # detector quantisation is 1 count
    bad = np.abs(r) > thresh * mad
    out = I.astype(float).copy()
    out[bad] = m[bad]
    return out, int(bad.sum())


def sdm_stats(theta, I, n_prism, window=SG_WINDOW):
    """Derivative-method index and peak-shape descriptors, identical for data and simulation."""
    thc, dI, k = derivative_peak(theta, I, window=window)
    n = n_prism * math.sin(math.radians(thc))
    half = dI[k] / 2
    left = k
    while left > 0 and dI[left] > half:
        left -= 1
    right = k
    while right < len(dI) - 1 and dI[right] > half:
        right += 1
    above = theta > thc + 0.3
    plateau = float(np.median(I[above][:100])) if above.sum() > 10 else float("nan")
    return dict(theta_c=thc, n_sdm=n, fwhm=theta[right] - theta[left],
                asym=(theta[right] - thc) - (thc - theta[left]),
                Rc_rel=float(np.interp(thc, theta, I)) / plateau, plateau=plateau)


def sdm_index(scan: Scan, window=SG_WINDOW, clean=True):
    I = despike(scan.I)[0] if clean else scan.I
    return sdm_stats(scan.theta, I, scan.n_prism, window)


# ------------------------------------------------------------------ Fresnel edge fit

def fit_edge(scan: Scan, k_ext: float, theta_c0: float, lo=0.8, hi=0.4, sigma0=0.02):
    """Fit I(theta) = A * [R_pol (x) G_sigma](theta) + B + C*(theta - theta_c0)
    over [theta_c0 - lo, theta_c0 + hi]. Free: n, sigma, A, B, C. k fixed (literature).
    Returns dict with fitted n (relative to air, via prism index), sigma, residual rms."""
    sel = (scan.theta > theta_c0 - lo) & (scan.theta < theta_c0 + hi)
    th, I = scan.theta[sel], scan.I[sel]
    npz = scan.n_prism
    n0 = npz * math.sin(math.radians(theta_c0))
    plateau = float(np.median(I[th > theta_c0 + 0.1])) if np.any(th > theta_c0 + 0.1) else I.max()
    floor = float(np.median(I[th < theta_c0 - 0.5])) if np.any(th < theta_c0 - 0.5) else I.min()

    def model(p):
        n, s, A, B, C = p
        R = blurred_R(th, (n + 1j * k_ext) / npz, scan.pol, abs(s))
        return A * R + B + C * (th - theta_c0)

    R_floor = float(fresnel_R(np.array([theta_c0 - lo + 0.1]), (n0 + 1j * k_ext) / npz, scan.pol)[0])
    A0 = (plateau - floor) / max(1 - R_floor, 0.2)
    p0 = [n0, sigma0, A0, plateau - A0, 0.0]
    res = least_squares(lambda p: model(p) - I, p0,
                        x_scale=[1e-4, 0.01, A0 * 0.05, A0 * 0.05, 10.0],
                        bounds=([n0 - 0.003, 0.001, 0, -np.inf, -np.inf],
                                [n0 + 0.003, 0.2, np.inf, np.inf, np.inf]))
    J = res.jac
    dof = max(len(I) - len(p0), 1)
    s2 = float(np.sum(res.fun**2) / dof)
    try:
        cov = np.linalg.inv(J.T @ J) * s2
        n_err = float(np.sqrt(cov[0, 0]))
    except np.linalg.LinAlgError:
        n_err = float("nan")
    n, s, A, B, C = res.x
    return dict(n_fit=float(n), n_fit_err=n_err, sigma=float(abs(s)), A=float(A), B=float(B),
                C=float(C), rms=math.sqrt(s2), npts=int(sel.sum()), ok=bool(res.success))


# ------------------------------------------------------------------ simulation of SDM bias

def simulate_sdm(pol, n_true, k_ext, n_prism, sigma_deg, step_deg=0.0036,
                 window=SG_WINDOW, scale=420.0, offset=15.0, kernel="gauss"):
    """Synthetic scan -> same derivative-method code as the data.
    Returns dict(bias = n_sdm - n_true, fwhm, asym, Rc_rel)."""
    thc_true = math.degrees(math.asin(n_true / n_prism))
    th = np.arange(thc_true - 2.0, thc_true + 1.5, step_deg)
    I = scale * blurred_R(th, (n_true + 1j * k_ext) / n_prism, pol, sigma_deg, kernel=kernel) + offset
    st = sdm_stats(th, I, n_prism, window)
    st["bias"] = st["n_sdm"] - n_true
    return st


def sdm_bias(lam, pol, n_true, k_ext, n_prism, sigma_deg, step_deg=0.0036, window=SG_WINDOW):
    return simulate_sdm(pol, n_true, k_ext, n_prism, sigma_deg, step_deg, window)["bias"]
