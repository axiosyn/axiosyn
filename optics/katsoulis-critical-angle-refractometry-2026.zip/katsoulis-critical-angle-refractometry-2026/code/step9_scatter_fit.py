"""Step 9 (feasibility): coherent extinction of Intralipid from the full shape of the reflectance edge.

The EDM (step 5) uses only (theta_c, R_c), so light scattered back diffusely into the detector
raises R_c and biases k low. Here each air-normalized Intralipid profile is fitted over
theta_c - 2 deg ... theta_c + 2 deg with
    R(theta) = a + b * R_coh(theta + dth; n + i k, sigma_water)
a = diffuse floor, b = (1 - a) x residual normalization. Physically, a diffuse term proportional
to the coherent loss, beta*(1 - R_coh), gives exactly this affine form with a = beta, b = 1 - beta.
k then comes from the knee shape (edge width/rounding), not from the level of R_c.
Fits: 'free' (a, b free) and 'nodiff' (a = 0, b free) for comparison.
Output: results/scatter_fits.csv
"""
import csv
import math
import os
import sys

import numpy as np
from scipy.optimize import least_squares

import water_lib as W
import step5_turbid as S5

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
SPAN = (-2.0, 2.0)


def fit_profile(th, R, pol, n_p, sigma, dth, n0, k0, free_a=True):
    def model(p, t):
        n, lk, a, b = p if free_a else (p[0], p[1], 0.0, p[2])
        return a + b * W.blurred_R(t + dth, (n + 1j * 10 ** lk) / n_p, pol, sigma)

    def res(p):
        return model(p, th) - R

    best = None
    for lk0 in (math.log10(max(k0, 1e-5)), -3.0, -2.5, -2.0):
        x0 = [n0, lk0, 0.05, 0.95] if free_a else [n0, lk0, 1.0]
        lo = [n0 - 0.01, -5, -0.2, 0.5] if free_a else [n0 - 0.01, -5, 0.5]
        hi = [n0 + 0.01, -1, 0.5, 1.5] if free_a else [n0 + 0.01, -1, 1.5]
        r = least_squares(res, x0, bounds=(lo, hi), x_scale=[1e-3, 0.1, 0.02, 0.02][: len(x0)] if free_a else [1e-3, 0.1, 0.02])
        if best is None or r.cost < best.cost:
            best = r
    p = best.x
    J = best.jac
    dof = max(len(th) - len(p), 1)
    s2 = 2 * best.cost / dof
    try:
        cov = np.linalg.inv(J.T @ J) * s2
        lk_err = float(math.sqrt(cov[1, 1]))
    except np.linalg.LinAlgError:
        lk_err = float("nan")
    out = dict(n=p[0], k=10 ** p[1], lk_err=lk_err, rms=math.sqrt(s2))
    out.update(dict(a=p[2], b=p[3]) if free_a else dict(a=0.0, b=p[2]))
    return out


def main():
    scans = [r for r in csv.DictReader(open(os.path.join(RES, "turbid_scans.csv"), encoding="utf-8"))
             if r["sample"] == "intralipid"]
    rows = []
    for r in scans:
        lam, pol = int(r["lam"]), r["pol"]
        folder = os.path.join(S5.ROOT, r["folder"])
        med, air = S5.load(os.path.join(folder, r["file"])), S5.load(os.path.join(folder, r["air"]))
        R = med["I"] / np.interp(med["theta"], air["theta"], air["I"], left=np.nan, right=np.nan)
        thc = float(r["theta_c"])
        m = np.isfinite(R) & (med["theta"] > thc + SPAN[0]) & (med["theta"] < thc + SPAN[1])
        th, Rm = med["theta"][m], R[m]
        n_p, dth = float(r["n_prism"]), float(r["dth_rot"])
        n0, k0 = float(r["n_renorm"]), float(r["k_renorm"])
        out = dict(lam=lam, pol=pol, method=r["method"], num=r["num"], n_edm=n0, k_edm=k0)
        for sig_tag, sig in (("", S5.SIGMA[lam]), ("_sighi", S5.SIGMA[lam] + S5.SIGMA_U[lam])):
            f = fit_profile(th, Rm, pol, n_p, sig, dth, n0, k0, True)
            out.update({f"{k}_free{sig_tag}": v for k, v in f.items()})
        g = fit_profile(th, Rm, pol, n_p, S5.SIGMA[lam], dth, n0, k0, False)
        out.update({f"{k}_nodiff": v for k, v in g.items()})
        rows.append(out)
        print(f"{lam:5d} {pol} {r['method']:4s} #{int(r['num']):02d}  EDM k={k0:.2e} | free: n={out['n_free']:.4f} "
              f"k={out['k_free']:.2e} a={out['a_free']:.3f} b={out['b_free']:.3f} rms={out['rms_free']:.4f} "
              f"(sig+u k={out['k_free_sighi']:.2e}) | nodiff: k={out['k_nodiff']:.2e} rms={out['rms_nodiff']:.4f}")
    with open(os.path.join(RES, "scatter_fits.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("\nmedians per wavelength/pol:")
    for lam in (532, 964, 1551):
        for pol in ("TE", "TM"):
            s = [x for x in rows if x["lam"] == lam and x["pol"] == pol]
            if s:
                f = lambda key: np.median([x[key] for x in s])
                print(f"{lam} {pol} N={len(s)}  k_EDM={f('k_edm'):.2e}  k_free={f('k_free'):.2e} "
                      f"(IQR {np.percentile([x['k_free'] for x in s],25):.2e}-{np.percentile([x['k_free'] for x in s],75):.2e})  "
                      f"a={f('a_free'):.3f}  k_nodiff={f('k_nodiff'):.2e}  rms free/nodiff={f('rms_free'):.4f}/{f('rms_nodiff'):.4f}")


if __name__ == "__main__":
    main()
