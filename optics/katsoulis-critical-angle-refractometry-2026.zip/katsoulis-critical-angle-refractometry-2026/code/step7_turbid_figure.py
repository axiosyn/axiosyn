"""Step 7: figure of turbid-media indices -> figures/figT1_turbid.png/pdf"""
import csv
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import water_lib as W

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES, FIG = os.path.join(HERE, "results"), os.path.join(HERE, "figures")
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e4e3df"
C = {"TE": "#2a78d6", "TM": "#eb6834"}; MK = {"TE": "o", "TM": "s"}
plt.rcParams.update({
    "font.size": 8.5, "axes.labelsize": 8.5, "axes.titlesize": 9, "legend.fontsize": 7.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 1.6, "savefig.dpi": 300,
    "legend.frameon": False, "font.family": "DejaVu Sans",
})

def rd(n):
    rows = list(csv.DictReader(open(os.path.join(RES, n), encoding="utf-8")))
    for r in rows:
        for k, v in r.items():
            try: r[k] = float(v)
            except ValueError: pass
    return rows

pp, cb = rd("turbid_per_pol.csv"), rd("turbid_summary.csv")
lam = np.linspace(430, 1600, 300)
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.9), sharey=True)
for ax, s, title in ((axs[0], "intralipid", "(a) Intralipid"), (axs[1], "cream", "(b) milk cream (35 % fat)")):
    ax.plot(lam, W.n_iapws_rel_air(lam, 25), color=MUTED, lw=1.1, ls="--", label="water (IAPWS, rel. air)")
    for pol in ("TE", "TM"):
        v = [p for p in pp if p["sample"] == s and p["pol"] == pol]
        off = -10 if pol == "TE" else 10
        filled = s == "intralipid"
        ax.errorbar([p["lam"] + off for p in v], [p["n"] for p in v],
                    yerr=[p["sd"] if p["sd"] == p["sd"] else 0 for p in v], fmt=MK[pol], ms=4.5, color=C[pol],
                    mfc=C[pol] if filled else "white", elinewidth=0.9, capsize=0, label=pol)
    if s == "intralipid":
        v = [c for c in cb if c["sample"] == s]
        ax.errorbar([c["lam"] for c in v], [c["n"] for c in v], yerr=[c["u_abs"] for c in v], fmt="_", ms=14,
                    color=INK, elinewidth=1.2, capsize=0, label="combined (±abs. unc.)", zorder=5)
    ax.set_title(title, loc="left"); ax.set_xlabel("wavelength (nm)")
    ax.legend(loc="upper right")
axs[0].set_ylabel("n (relative to air), 25 °C")
axs[1].text(0.03, 0.04, "open markers: TE/TM disagree; not a reliable n", transform=axs[1].transAxes, fontsize=7, color=INK2)
axs[0].set_ylim(1.305, 1.395)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "figT1_turbid.png"), bbox_inches="tight"); fig.savefig(os.path.join(FIG, "figT1_turbid.pdf"), bbox_inches="tight")
print("wrote figT1_turbid")
