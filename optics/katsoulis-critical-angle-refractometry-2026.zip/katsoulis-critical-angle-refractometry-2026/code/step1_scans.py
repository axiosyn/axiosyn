"""Step 1: per-scan derivative-method analysis -> results/scans.csv"""
import csv
import os
import sys

import water_lib as W

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "Ierotheos")
OUT = os.path.join(HERE, "results")
os.makedirs(OUT, exist_ok=True)

WINDOWS = (9, 15, 21)

rows = []
for s in W.load_all(DATA):
    r = dict(file=os.path.basename(s.path), internal_name=s.internal_name, time=s.time.isoformat(),
             lam=s.lam, T=s.T, T_nominal=s.T_nominal, pol=s.pol, rep=s.rep, direction=s.direction,
             n_prism=round(s.n_prism, 5), tempco=s.tempco, npts=len(s.theta),
             step=float(abs(s.theta[1] - s.theta[0])))
    for w in WINDOWS:
        d = W.sdm_index(s, window=w)
        r[f"n_w{w}"] = d["n_sdm"]
        if w == W.SG_WINDOW:
            r.update(theta_c=d["theta_c"], fwhm=d["fwhm"], asym=d["asym"], Rc_rel=d["Rc_rel"],
                     plateau=d["plateau"])
    rows.append(r)

with open(os.path.join(OUT, "scans.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
print(f"{len(rows)} scans -> results/scans.csv")
