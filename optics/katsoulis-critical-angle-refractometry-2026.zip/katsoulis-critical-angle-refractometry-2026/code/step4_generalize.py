"""Step 4 (methods paper): how the derivative-method TE/TM artefact depends on
sample/prism index ratio, angular spread, smoothing window and absorption.
Outputs: results/artefact_vs_ratio.csv, results/artefact_budget_water.csv, figures/figM1_generalized.*"""
import csv
import math
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import water_lib as W

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES, FIG = os.path.join(HERE, "results"), os.path.join(HERE, "figures")

INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e4e3df"
plt.rcParams.update({
    "font.size": 8.5, "axes.labelsize": 8.5, "axes.titlesize": 9, "legend.fontsize": 7.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 1.6, "savefig.dpi": 300,
    "legend.frameon": False, "font.family": "DejaVu Sans",
})
SEQ = ["#86b6ef", "#3987e5", "#256abf", "#104281"]   # one-hue ramp: increasing index ratio

NP, LAM, STEP = 1.9642, 633, 0.0036

def art(n, k, sg, window=W.SG_WINDOW, npz=NP, kernel="gauss"):
    te = W.simulate_sdm("TE", n, k, npz, sg, STEP, window, kernel=kernel)
    tm = W.simulate_sdm("TM", n, k, npz, sg, STEP, window, kernel=kernel)
    return te["bias"], tm["bias"], tm["bias"] - te["bias"]

# (a) artefact vs sigma for several sample indices (transparent sample, 633 nm prism)
ratios = [0.60, 0.68, 0.76, 0.84]          # n/n_p ; water on this prism ~0.677
sig = np.round(np.arange(0.0, 0.0501, 0.0025), 4)
rows = []
for q in ratios:
    for s in sig:
        bte, btm, d = art(q * NP, 0.0, s)
        rows.append(dict(ratio=q, n=q * NP, sigma=s, bias_TE=bte, bias_TM=btm, d=d,
                         d_theta_deg=math.degrees(d / (NP * math.cos(math.asin(q))))))
with open(os.path.join(RES, "artefact_vs_ratio.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

# (b) budget for water: smoothing only / + angular spread / + absorption
inf = {(int(r["lam"]), int(float(r["T"]))): r for r in csv.DictReader(open(os.path.join(RES, "blur_inference.csv"), encoding="utf-8"))}
npz = {532: 1.9775, 633: 1.9642, 964: 1.945, 1551: 1.934}
nw = {532: 1.3347, 633: 1.3305, 964: 1.3242, 1551: 1.3151}
budget = []
for lam in (532, 633, 964, 1551):
    sg = float(inf[(lam, 25)]["sigma"])
    k = W.K_WATER[lam]
    d0 = art(nw[lam], 0.0, 0.0, npz=npz[lam])[2]            # smoothing + sampling only
    d1 = art(nw[lam], 0.0, sg, npz=npz[lam])[2]             # + angular spread
    d2 = art(nw[lam], k, sg, npz=npz[lam])[2]               # + absorption (literature k)
    dw5 = art(nw[lam], k, sg, window=5, npz=npz[lam])[2]    # minimal smoothing
    budget.append(dict(lam=lam, sigma=sg, k=k, smoothing=d0, spread=d1 - d0, absorption=d2 - d1, total=d2, total_w5=dw5))
    print(f"{lam:5d} nm: smoothing {d0*1e5:+.2f}  spread {(d1-d0)*1e5:+.2f}  absorption {(d2-d1)*1e5:+.2f}  total {d2*1e5:+.2f}  (5-pt window {dw5*1e5:+.2f}) e-5")
with open(os.path.join(RES, "artefact_budget_water.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(budget[0].keys())); w.writeheader(); w.writerows(budget)

for q in ratios:
    v = [r for r in rows if r["ratio"] == q and r["sigma"] in (0.0, 0.02, 0.04)]
    print(f"n/n_p={q:.2f}: " + "  ".join(f"sigma={r['sigma']:.2f}: dn={r['d']*1e5:+.1f}e-5 ({r['d_theta_deg']*1e3:+.1f} mdeg)" for r in v))

# ---- figure
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.8), gridspec_kw=dict(width_ratios=[1.25, 1]))
ax = axs[0]
for q, c in zip(ratios, SEQ):
    v = [r for r in rows if r["ratio"] == q]
    ax.plot([r["sigma"] for r in v], [r["d"] * 1e5 for r in v], color=c, label=f"n/n_p = {q:.2f}" + (" (≈ water)" if q == 0.68 else ""))
ax.set_xlabel("angular spread σ (deg)"); ax.set_ylabel("apparent $n_{TM}-n_{TE}$  ($10^{-5}$)")
ax.set_title("(a) transparent sample, 15-point smoothing", loc="left"); ax.legend(loc="upper left")
ax = axs[1]
x = np.arange(len(budget)); wdt = 0.6
parts = [("smoothing", "sampling & smoothing", "#86b6ef"), ("spread", "angular spread", "#2a78d6"), ("absorption", "absorption", "#eb6834")]
bottom = np.zeros(len(budget))
for key, lab, col in parts:
    h = np.array([b[key] for b in budget]) * 1e5
    ax.bar(x, h, wdt, bottom=bottom, color=col, label=lab, edgecolor="white", linewidth=1.0)
    bottom += h
ax.set_xticks(x); ax.set_xticklabels([f"{b['lam']} nm" for b in budget])
ax.set_ylabel("predicted $n_{TM}-n_{TE}$  ($10^{-5}$)"); ax.set_title("(b) water: where the artefact comes from", loc="left")
ax.legend(loc="upper left")
ax.set_ylim(0, 11)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "figM1_generalized.png"), bbox_inches="tight"); fig.savefig(os.path.join(FIG, "figM1_generalized.pdf"), bbox_inches="tight")
print("wrote figM1_generalized")
