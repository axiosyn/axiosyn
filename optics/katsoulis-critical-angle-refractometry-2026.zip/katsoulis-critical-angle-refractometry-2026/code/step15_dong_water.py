"""Step 15: the water test for Dong et al.'s angle-dependent model.

Same idea as step 11: water's k is known, so whatever k a model returns above it is the model's bias.
Water scans have no air reference, so both models carry a free offset a and scale b (raw counts / plateau).
Fit range theta_c +- 2 deg, first 6 scans per wavelength/polarization at 25 C (both directions).
Models (from step 14): AM_floor = a + b * blurred Dong model; OURS = a + b * blurred Fresnel.
Output: results/dong_water.csv
"""
import csv
import math
import os
import sys

import numpy as np

import water_lib as W
import step14_dong_model as D
import step11_water_k_check as S11

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")


def main():
    rows, count = [], {}
    for s in W.load_all(S11.DATA):
        if s.T_nominal != 25 or s.direction not in ("L", "R") or s.lam not in S11.SIG:
            continue
        key = (s.lam, s.pol)
        if count.get(key, 0) >= 6:
            continue
        count[key] = count.get(key, 0) + 1
        I, _ = W.despike(s.I)
        st = W.sdm_stats(s.theta, I, s.n_prism)
        thc = st["theta_c"]
        sign = 1.0 if s.direction == "R" else -1.0
        dth = sign * math.degrees(S11.LAG[s.lam] / (s.n_prism * math.cos(math.radians(thc))))
        m = (s.theta > thc - 2.0) & (s.theta < thc + 2.0)
        th = s.theta[m]
        y = I[m] / float(np.median(I[m][th > thc + 1.0]))
        out = dict(lam=s.lam, pol=s.pol, dir=s.direction, file=os.path.basename(s.path), k_true=W.K_WATER[s.lam])
        for name in ("OURS", "AM_floor"):
            p, res = D.fit(name, th, y, s.pol, s.n_prism, S11.SIG[s.lam], dth, st["n_sdm"])
            out[f"{name}_k"], out[f"{name}_rms"] = 10 ** p[1], float(np.sqrt(np.mean(res ** 2)))
        rows.append(out)
        print(f"{s.lam:5d} {s.pol} {s.direction}  OURS k={out['OURS_k']:.2e} rms={out['OURS_rms']:.4f} | "
              f"Dong k={out['AM_floor_k']:.2e} rms={out['AM_floor_rms']:.4f}", flush=True)
    with open(os.path.join(RES, "dong_water.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("\nmedians:")
    for lam in sorted({r["lam"] for r in rows}):
        for pol in ("TE", "TM"):
            s = [r for r in rows if r["lam"] == lam and r["pol"] == pol]
            md = lambda k: float(np.median([r[k] for r in s]))
            print(f"{lam} {pol} N={len(s)} k_true={W.K_WATER[lam]:.1e}  OURS k={md('OURS_k'):.2e} rms={md('OURS_rms'):.4f}  "
                  f"Dong k={md('AM_floor_k'):.2e} rms={md('AM_floor_rms'):.4f}")


if __name__ == "__main__":
    main()
