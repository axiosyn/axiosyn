"""Step 12: Intralipid scattering vs. dependent-scattering prediction, with the method's bias floor
(measured on water, step 11) subtracted per wavelength and polarization.
DS prediction: Attendu et al., J. Biomed. Opt. 31, 085003 (2026), Eq. 13 + Table 1 (independent
scattering) times the Aernouts-type packing factor (1-phi)^(p+1) / (1+phi(p-1))^(p-1), p = p1 + p2 lambda/600.
(Reconstruction checked against the paper's statement that IS overestimates mu_s by >40 % at 800 nm, phi = 0.114.)
Output: results/scatter_vs_DS.csv"""
import csv, math, os
import numpy as np
import water_lib as W
RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
PHI = 0.227
def is_att(l): x = l / 600; return 108.2 * x ** (-2.516 - 0.4036 * math.log10(x))
def packing(l, phi=PHI): p = 1.207 + 0.3078 * l / 600; return (1 - phi) ** (p + 1) / (1 + phi * (p - 1)) ** (p - 1)
mu = lambda k, l: 4 * math.pi * k / (l * 1e-6)

def main():
    fits = list(csv.DictReader(open(os.path.join(RES, "scatter_fits.csv"), encoding="utf-8")))
    wat = list(csv.DictReader(open(os.path.join(RES, "water_k_check.csv"), encoding="utf-8")))
    summ = {int(r["lam"]): r for r in csv.DictReader(open(os.path.join(RES, "scatter_summary.csv"), encoding="utf-8"))}
    rows = []
    for lam in (532, 964, 1551):
        kc = {}
        for pol in ("TE", "TM"):
            k_il = np.median([float(r["k_free"]) for r in fits if int(r["lam"]) == lam and r["pol"] == pol])
            floor = np.median([float(r["k_fit"]) for r in wat if int(r["lam"]) == lam and r["pol"] == pol]) - W.K_WATER[lam]
            kc[pol] = (k_il, floor, k_il - floor)
        k_corr = np.mean([v[2] for v in kc.values()])
        floor_u = abs(kc["TE"][1] - kc["TM"][1]) / 2 + np.mean([v[1] for v in kc.values()]) / 2   # floor known to ~50 %
        u = math.hypot(float(summ[lam]["k_stat"]), float(summ[lam]["k_sys"]), floor_u)
        mua = mu(W.K_WATER[lam] * (1 - PHI), lam)
        mus = mu(k_corr, lam) - mua
        ds = is_att(lam) * packing(lam)
        rows.append(dict(lam=lam, k_TE=kc["TE"][0], floor_TE=kc["TE"][1], k_TM=kc["TM"][0], floor_TM=kc["TM"][1],
                         k_corr_TE=kc["TE"][2], k_corr_TM=kc["TM"][2], mu_s=mus, mu_s_u=mu(u, lam),
                         mu_s_uncorrected=float(summ[lam]["mu_s"]), IS=is_att(lam), packing=packing(lam), DS=ds,
                         ratio_DS=mus / ds, ratio_DS_u=mu(u, lam) / ds))
        print(f"{lam:5d}  k TE {kc['TE'][0]:.2e}-{kc['TE'][1]:.1e}={kc['TE'][2]:.2e}  TM {kc['TM'][0]:.2e}-{kc['TM'][1]:.1e}={kc['TM'][2]:.2e} | "
              f"mu_s {mus:.1f}+-{mu(u, lam):.1f} (uncorr {float(summ[lam]['mu_s']):.1f})  IS {is_att(lam):.1f}  DS {ds:.1f}  "
              f"meas/DS {mus / ds:.2f}+-{mu(u, lam) / ds:.2f}  meas/IS {mus / is_att(lam):.2f}")
    with open(os.path.join(RES, "scatter_vs_DS.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)


if __name__ == "__main__":
    main()
