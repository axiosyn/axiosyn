"""Step 10 (feasibility): coherent extinction coefficient of undiluted Intralipid-20 % vs. wavelength,
compared with the independent-scattering prediction.

k from step 9 (edge-shape fit with diffuse floor) -> mu_ext = 4 pi k / lambda.
Systematic spread: k re-fitted with windows +-1, +-2, +-3 deg, asymmetric -1/+2.5 deg and a sloped
diffuse term (slow-method scans); the half-range of the variant medians is the systematic error.
Water absorption in the aqueous phase (1 - phi) is subtracted to give the scattering part.
Reference: independent-scattering fit for Intralipid-20 % by Shahsavari et al., J. Biomed. Opt. 31,
015001 (2026): mu_s = 163.7 (lambda/500 nm)^-2.546 mm^-1 for the undiluted stock (phi = 0.227),
derived from a measured particle-size distribution and valid for dilute samples (phi < 0.02).
Outputs: results/scatter_summary.csv, figures/figS1_extinction.{png,pdf}
"""
import csv
import math
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import least_squares

import water_lib as W
import step5_turbid as S5

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES, FIG = os.path.join(HERE, "results"), os.path.join(HERE, "figures")
PHI = 0.227
LAMS = (532, 964, 1551)
VARIANTS = {"span1": (-1, 1, 0), "span2": (-2, 2, 0), "span3": (-3, 3, 0), "asym": (-1, 2.5, 0), "slope2": (-2, 2, 1)}


def mu_s_independent(lam):
    return 163.7 * (lam / 500.0) ** -2.546


def mu_from_k(k, lam):
    return 4 * math.pi * k / (lam * 1e-6)          # mm^-1


def fit_k(th, R, pol, n_p, sig, dth, n0, slope):
    t0 = th.mean()

    def model(p):
        n, lk, a, b = p[:4]
        s = p[4] if slope else 0.0
        return a + s * (th - t0) + b * W.blurred_R(th + dth, (n + 1j * 10 ** lk) / n_p, pol, sig)

    best = None
    for lk0 in (-3.5, -3.0, -2.5, -2.0):
        x0 = [n0, lk0, 0.1, 0.9] + ([0.0] if slope else [])
        lo = [n0 - 0.01, -5, -0.2, 0.5] + ([-1] if slope else [])
        hi = [n0 + 0.01, -1, 0.5, 1.5] + ([1] if slope else [])
        r = least_squares(lambda p: model(p) - R, x0, bounds=(lo, hi))
        if best is None or r.cost < best.cost:
            best = r
    return 10 ** best.x[1]


def variant_spread():
    scans = [r for r in csv.DictReader(open(os.path.join(RES, "turbid_scans.csv"), encoding="utf-8"))
             if r["sample"] == "intralipid" and r["method"] == "slow"]
    out = {}
    for r in scans:
        lam, pol = int(r["lam"]), r["pol"]
        folder = os.path.join(S5.ROOT, r["folder"])
        med, air = S5.load(os.path.join(folder, r["file"])), S5.load(os.path.join(folder, r["air"]))
        R = med["I"] / np.interp(med["theta"], air["theta"], air["I"], left=np.nan, right=np.nan)
        thc = float(r["theta_c"])
        for tag, (lo, hi, sl) in VARIANTS.items():
            m = np.isfinite(R) & (med["theta"] > thc + lo) & (med["theta"] < thc + hi)
            k = fit_k(med["theta"][m], R[m], pol, float(r["n_prism"]), S5.SIGMA[lam], float(r["dth_rot"]),
                      float(r["n_renorm"]), sl)
            out.setdefault((lam, tag), []).append(k)
    return {lam: {t: float(np.median(out[(lam, t)])) for t in VARIANTS} for lam in LAMS}


def main():
    fits = list(csv.DictReader(open(os.path.join(RES, "scatter_fits.csv"), encoding="utf-8")))
    var = variant_spread()
    rows = []
    for lam in LAMS:
        s = [r for r in fits if int(r["lam"]) == lam]
        k_scan = np.array([float(r["k_free"]) for r in s])
        k_pol = {p: float(np.median([float(r["k_free"]) for r in s if r["pol"] == p])) for p in ("TE", "TM")}
        k_med = float(np.median(k_scan))
        q1, q3 = np.percentile(k_scan, [25, 75])
        k_stat = (q3 - q1) / 1.349 / math.sqrt(len(k_scan))          # robust SEM
        kv = list(var[lam].values())
        k_sys = (max(kv) - min(kv)) / 2
        k_u = math.hypot(k_stat, k_sys)
        mu_ext, mu_u = mu_from_k(k_med, lam), mu_from_k(k_u, lam)
        mu_a_w = mu_from_k(W.K_WATER[lam] * (1 - PHI), lam)
        mu_s = mu_ext - mu_a_w
        mu_ind = mu_s_independent(lam)
        a_med = float(np.median([float(r["a_free"]) for r in s]))
        rows.append(dict(lam=lam, N=len(s), k=k_med, k_TE=k_pol["TE"], k_TM=k_pol["TM"], k_stat=k_stat, k_sys=k_sys,
                         mu_ext=mu_ext, mu_u=mu_u, mu_a_water=mu_a_w, mu_s=mu_s, mu_s_indep=mu_ind,
                         ratio=mu_s / mu_ind, ratio_u=mu_u / mu_ind, diffuse_floor=a_med,
                         **{f"k_{t}": v for t, v in var[lam].items()}))
        print(f"{lam:5d} nm  N={len(s):2d}  k={k_med:.2e} (TE {k_pol['TE']:.2e} / TM {k_pol['TM']:.2e}) "
              f"+-{k_stat:.1e} stat +-{k_sys:.1e} sys | mu_ext={mu_ext:.1f}+-{mu_u:.1f}/mm  water mu_a={mu_a_w:.2f} "
              f"mu_s={mu_s:.1f}  indep={mu_ind:.1f}  ratio={mu_s / mu_ind:.2f}+-{mu_u / mu_ind:.2f}  floor a={a_med:.3f}")
    with open(os.path.join(RES, "scatter_summary.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    lam_arr = np.array([r["lam"] for r in rows], float)
    mu_arr = np.array([r["mu_s"] for r in rows])
    slope, icpt = np.polyfit(np.log(lam_arr), np.log(mu_arr), 1)
    print(f"\npower law of measured mu_s: exponent {-slope:.2f} (independent-scattering fit: 2.546)")
    print(f"mean ratio measured / independent: {np.mean([r['ratio'] for r in rows]):.2f}")

    # ------------------------------------------------------------ figure
    INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e4e3df"
    C = {"TE": "#2a78d6", "TM": "#eb6834"}
    plt.rcParams.update({
        "font.size": 8.5, "axes.labelsize": 8.5, "legend.fontsize": 7.5, "xtick.labelsize": 7.5,
        "ytick.labelsize": 7.5, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
        "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
        "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300, "legend.frameon": False,
        "font.family": "DejaVu Sans"})
    fig, ax = plt.subplots(figsize=(3.6, 3.9))
    g = np.geomspace(480, 1650, 200)
    ax.plot(g, mu_s_independent(g), color=INK2, lw=1.4, label="independent scattering (Shahsavari 2026)")
    ax.plot(g, 0.5 * mu_s_independent(g), color=INK2, lw=1.0, ls="--", label="0.5 × independent")
    mk = {"TE": "o", "TM": "s"}
    for pol, dx in (("TE", 0.985), ("TM", 1.015)):
        for r in fits:
            if r["pol"] == pol:
                lam = int(r["lam"])
                ax.plot(lam * dx, mu_from_k(float(r["k_free"]), lam) - mu_from_k(W.K_WATER[lam] * (1 - PHI), lam),
                        mk[pol], ms=3, color=C[pol], alpha=0.35, mec="none")
    ax.errorbar(lam_arr, mu_arr, yerr=[r["mu_u"] for r in rows], fmt="D", ms=6, color=INK, mfc="white", mew=1.4,
                capsize=3, lw=1.2, label="this work, median ± u", zorder=5)
    ax.plot([], [], "o", ms=4, color=C["TE"], label="single scans, TE")
    ax.plot([], [], "s", ms=4, color=C["TM"], label="single scans, TM")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xticks([500, 700, 1000, 1500]); ax.set_xticklabels(["500", "700", "1000", "1500"])
    ax.minorticks_off()
    ax.set_xlabel("wavelength (nm)"); ax.set_ylabel("scattering coefficient $\\mu_s$ (mm$^{-1}$)")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2, fontsize=6.6)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "figS1_extinction.png"), bbox_inches="tight")
    fig.savefig(os.path.join(FIG, "figS1_extinction.pdf"), bbox_inches="tight")
    print("wrote figS1_extinction")


if __name__ == "__main__":
    main()
