"""Step 8: measured air-normalized profiles vs. model at the solved (n, k) -> figures/figT2_profiles.*"""
import csv
import glob
import math
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import water_lib as W

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..", "Measurments_Iero", "Turbid Media")
RES, FIG = os.path.join(HERE, "results"), os.path.join(HERE, "figures")
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e4e3df"
C = {"TE": "#2a78d6", "TM": "#eb6834"}
plt.rcParams.update({
    "font.size": 8.5, "axes.labelsize": 8.5, "axes.titlesize": 9, "legend.fontsize": 7.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 1.6, "savefig.dpi": 300,
    "legend.frameon": False, "font.family": "DejaVu Sans",
})
sig = {int(r["lam"]): float(r["sigma"]) for r in csv.DictReader(open(os.path.join(RES, "blur_inference.csv"), encoding="utf-8")) if float(r["T"]) == 25}
scans = list(csv.DictReader(open(os.path.join(RES, "turbid_scans.csv"), encoding="utf-8")))

def load(p):
    L = open(p, encoding="latin-1").read().splitlines()
    d = []
    for l in L[3:]:
        try: d.append([float(x) for x in l.split(",")])
        except ValueError: pass
    d = np.array(d); d = d[np.argsort(d[:, 2])]
    return d[:, 2], W.despike(d[:, 4])[0]

panels = [("Intralipid/Slow_Method/1551", "intralipid", 1551, "(a) Intralipid, 1551 nm"),
          ("Cream/Slow/633", "cream", 633, "(b) milk cream, 633 nm")]
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.9), sharey=True)
for ax, (folder, s, lam, title) in zip(axs, panels):
    for pol in ("TE", "TM"):
        rs = [r for r in scans if r["folder"] == folder and r["pol"] == pol]
        thc_ref = np.mean([float(r["theta_c"]) for r in rs])
        for r in rs:
            th, Im = load(os.path.join(ROOT, folder, r["file"]))
            tha, Ia = load(os.path.join(ROOT, folder, r["air"]))
            R = Im / np.interp(th, tha, Ia, left=np.nan, right=np.nan)
            R *= float(r["Rc_renorm"]) / float(r["Rc"])          # plateau re-normalization used in the analysis
            ax.plot(th - thc_ref, R, color=C[pol], lw=0.5, alpha=0.45)
        n = np.mean([float(r["n_renorm"]) for r in rs]); k = np.median([float(r["k_renorm"]) for r in rs])
        npz = float(rs[0]["n_prism"]); dth = np.mean([float(r["dth_rot"]) for r in rs])
        g = np.linspace(thc_ref - 4, thc_ref + 3, 2000)
        Rm = W.blurred_R(g + dth, (n + 1j * k) / npz, pol, sig[lam])     # model on the measured (uncorrected) angle scale
        ax.plot(g - thc_ref, Rm, color=INK, lw=1.0, ls="--")
    ax.plot([], [], color=C["TE"], label="TE, measured"); ax.plot([], [], color=C["TM"], label="TM, measured")
    ax.plot([], [], color=INK, ls="--", lw=1.0, label="Fresnel model at solved (n, k)")
    ax.set_title(title, loc="left"); ax.set_xlabel("θ − θ_c (deg)"); ax.set_xlim(-3.5, 2.5)
axs[0].set_ylabel("R (air-normalized)"); axs[0].set_ylim(0, 1.12)
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=(0, 0.07, 1, 1))
fig.savefig(os.path.join(FIG, "figT2_profiles.png"), bbox_inches="tight"); fig.savefig(os.path.join(FIG, "figT2_profiles.pdf"), bbox_inches="tight")
print("wrote figT2_profiles")
