"""Step 5: complex refractive index of milk cream and Intralipid from air-normalized
critical-angle reflectance, with the instrument corrections derived from water.

For each medium scan:
  R(theta) = I_medium / I_air (air scan of same wavelength/polarization: same number for the
             'slow' method, nearest in time for the 'fast' method; README in Turbid Media/)
  (theta_c, R_c) at the maximum of dR/dtheta (Savitzky-Golay, window scaled to the edge width)
Then (n, k) from three analyses:
  SDM       n = n_p sin(theta_c)                                   (no correction)
  EDM       ideal Fresnel profile whose derivative maximum is at (theta_c, R_c)   [Koutsoumpos 2020]
  EDM+inst  same, but the model profile is blurred by the laser's angular spread (from water),
            sampled and smoothed exactly like the data, and theta_c is first corrected for the
            rotation-direction offset (all turbid scans were taken in direction R).
Outputs: results/turbid_scans.csv, results/turbid_summary.csv
"""
import csv
import glob
import math
import os
import re
import sys
from datetime import datetime

import numpy as np
from scipy.optimize import least_squares
from scipy.signal import savgol_filter

import water_lib as W

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..", "Measurments_Iero", "Turbid Media")
RES = os.path.join(HERE, "results")

# ---------------------------------------------------------------- instrument parameters from water
INF = {int(r["lam"]): r for r in csv.DictReader(open(os.path.join(RES, "blur_inference.csv"), encoding="utf-8"))
       if float(r["T"]) == 25.0}
SIGMA = {lam: float(r["sigma"]) for lam, r in INF.items()}
SIGMA_U = {lam: float(r["sigma_u"]) for lam, r in INF.items()}
SIGMA[450], SIGMA_U[450] = 0.020, 0.010            # no water data at 450 nm
NC = {int(r["lam"]): r for r in csv.DictReader(open(os.path.join(RES, "n_corrected.csv"), encoding="utf-8"))
      if float(r["T"]) == 25.0}
# rotation offset: n_mean - n_R = (n_L - n_R)/2 = 'lag' column, per wavelength (TE/TM averaged)
LAG = {}
for lam in (532, 633, 964, 1551):
    LAG[lam] = float(np.mean([float(r["lag"]) for r in csv.DictReader(open(os.path.join(RES, "n_corrected.csv"), encoding="utf-8"))
                              if int(r["lam"]) == lam and float(r["T"]) == 25.0]))
LAG[450] = float(np.mean(list(LAG.values())))
LAG_U = 0.6e-4   # spread of the 25 C water values

# ---------------------------------------------------------------- loading
NAME = re.compile(r"(air|cream|intralipid)_(\d+)_(T[EM])_(?:R_|auto_)(\d+)\.txt$")

def load(p):
    L = open(p, encoding="latin-1").read().splitlines()
    h = next(csv.reader([L[0]]))
    d = []
    for l in L[3:]:
        try:
            d.append([float(x) for x in l.split(",")])
        except ValueError:
            pass
    d = np.array(d)
    d = d[np.argsort(d[:, 2])]
    t = datetime.strptime(" ".join(h[4].split()), "%m/%d/%Y %I:%M:%S %p")
    k = len(d) // 2
    return dict(path=p, theta=d[:, 2], I=W.despike(d[:, 4])[0], time=t,
                n_prism=float(d[k, 3] / math.sin(math.radians(d[k, 2]))))

SETS = [  # folder, sample, method
    ("Cream/Slow/450", "cream", "slow"), ("Cream/Slow/532", "cream", "slow"), ("Cream/Slow/633", "cream", "slow"),
    ("Cream/Slow/964", "cream", "slow"), ("Cream/Slow/1551", "cream", "slow"), ("Cream/Fast", "cream", "fast"),
    ("Intralipid/Slow_Method/532", "intralipid", "slow"), ("Intralipid/Slow_Method/964", "intralipid", "slow"),
    ("Intralipid/Slow_Method/1551", "intralipid", "slow"), ("Intralipid/Fast_Method", "intralipid", "fast"),
]

# ---------------------------------------------------------------- measured (theta_c, R_c)
def peak_in(theta, d, lo, hi, w):
    """index of the maximum of d inside [lo, hi], away from filter edges"""
    idx = np.where((theta >= lo) & (theta <= hi))[0]
    idx = idx[(idx >= w) & (idx < len(theta) - w)]
    return int(idx[np.argmax(d[idx])])

def edge(theta, R, window_deg=None):
    step = float(np.median(np.diff(theta)))
    ok = np.isfinite(R)
    theta, R = theta[ok], R[ok]
    # coarse pass (0.6 deg smoothing) locates the edge robustly against noise
    wc = int(round(0.6 / step)) | 1
    dc = savgol_filter(R, wc, 2, deriv=1)
    kc = peak_in(theta, dc, theta[0], theta[-1], wc)
    half = dc[kc] / 2
    l, r = kc, kc
    while l > 0 and dc[l] > half: l -= 1
    while r < len(dc) - 1 and dc[r] > half: r += 1
    # second pass sizes the window to the (deconvolved) edge width
    w1 = int(round(0.15 / step)) | 1
    d1 = savgol_filter(R, w1, 2, deriv=1)
    k1 = peak_in(theta, d1, theta[l], theta[r], w1)
    h1 = d1[k1] / 2
    l1, r1 = k1, k1
    while l1 > 0 and d1[l1] > h1: l1 -= 1
    while r1 < len(d1) - 1 and d1[r1] > h1: r1 += 1
    fwhm = theta[r1] - theta[l1]
    if window_deg is None:
        window_deg = max(0.055, 0.15 * fwhm)
    w = max(int(round(window_deg / step)) | 1, 7)
    dR = savgol_filter(R, w, 2, deriv=1) / np.gradient(theta)
    k = peak_in(theta, dR, theta[l1] - 0.05, theta[r1] + 0.05, w)
    j0, j1 = max(k - 5, 0), min(k + 6, len(theta))
    c = np.polyfit(theta[j0:j1] - theta[k], dR[j0:j1], 2)
    thc = theta[k] - c[1] / (2 * c[0]) if c[0] < 0 and abs(c[1] / (2 * c[0])) < 3 * step else theta[k]
    Rc = float(np.interp(thc, theta, savgol_filter(R, w, 2)))
    plateau = float(np.median(R[(theta > thc + 1.5) & (theta < thc + 3.0)])) if np.any(theta > thc + 1.5) else float("nan")
    return dict(theta_c=thc, Rc=Rc, fwhm=fwhm, window=w, window_deg=w * step, step=step, plateau=plateau)

# ---------------------------------------------------------------- model (theta_c, R_c) for given (n, k)
def model_edge(pol, n, k, n_p, sigma, step, window, full=False):
    thc0 = math.degrees(math.asin(min(n / n_p, 0.999)))
    th = np.arange(thc0 - 5.0, thc0 + 4.0, step)
    R = W.blurred_R(th, (n + 1j * k) / n_p, pol, sigma)
    thc, dR, kk = W.derivative_peak(th, R, window=window)
    Rc = float(np.interp(thc, th, savgol_filter(R, window, 2)))
    if not full:
        return thc, Rc
    h = dR[kk] / 2
    l, r = kk, kk
    while l > 0 and dR[l] > h: l -= 1
    while r < len(dR) - 1 and dR[r] > h: r += 1
    plateau = float(np.median(R[(th > thc + 1.5) & (th < thc + 3.0)]))
    return thc, Rc, th[r] - th[l], plateau

def solve(pol, thc_meas, Rc_meas, n_p, sigma, step, window, start=None):
    n0 = n_p * math.sin(math.radians(thc_meas))
    def res(p):
        thc, Rc = model_edge(pol, p[0], 10 ** p[1], n_p, sigma, step, window)
        return [(thc - thc_meas) / 0.001, (Rc - Rc_meas) / 0.001]
    best = None
    for lk in ([start[1]] if start else []) + [-3.5, -2.8, -2.2, -1.7]:
        x0 = [start[0] if start else n0 + 0.002, lk]
        r = least_squares(res, x0, bounds=([n0 - 0.02, -6], [n0 + 0.03, -0.7]), x_scale=[1e-3, 0.2], diff_step=[1e-5, 1e-3])
        if best is None or r.cost < best.cost:
            best = r
    return best.x[0], 10 ** best.x[1], float(math.sqrt(2 * best.cost))

# ---------------------------------------------------------------- one medium scan + its air scan
def analyze_pair(med, air, lam, pol):
    """Air-normalize one medium scan and invert it three ways (SDM, ideal EDM, corrected EDM)."""
    Ia = np.interp(med["theta"], air["theta"], air["I"], left=np.nan, right=np.nan)
    R = med["I"] / Ia
    e = edge(med["theta"], R)
    n_p = med["n_prism"]
    # rotation offset (direction R reads low): shift theta_c up by the water-derived angle
    dth = math.degrees(LAG[lam] / (n_p * math.cos(math.radians(e["theta_c"]))))
    n_sdm = n_p * math.sin(math.radians(e["theta_c"]))
    # ideal EDM: fine sampling, negligible smoothing, no spread
    n_e, k_e, r_e = solve(pol, e["theta_c"], e["Rc"], n_p, 0.0, 0.0005, 5)
    n_c, k_c, r_c = solve(pol, e["theta_c"] + dth, e["Rc"], n_p, SIGMA[lam], e["step"], e["window"], start=(n_e, math.log10(k_e)))
    # variant: re-normalize R so that its plateau 1.5-3 deg above theta_c matches the model's
    n_r, k_r, r_r = n_c, k_c, r_c
    Rc_r = e["Rc"]
    if np.isfinite(e["plateau"]):
        for _ in range(2):
            pm = model_edge(pol, n_r, k_r, n_p, SIGMA[lam], e["step"], e["window"], full=True)[3]
            Rc_r = e["Rc"] * pm / e["plateau"]
            n_r, k_r, r_r = solve(pol, e["theta_c"] + dth, Rc_r, n_p, SIGMA[lam], e["step"], e["window"], start=(n_r, math.log10(max(k_r, 1e-6))))
    fw_model = model_edge(pol, n_r, k_r, n_p, SIGMA[lam], e["step"], e["window"], full=True)[2]
    return dict(n_prism=round(n_p, 5), theta_c=e["theta_c"], Rc=e["Rc"], fwhm=e["fwhm"], window_deg=e["window_deg"],
                plateau=e["plateau"], n_sdm=n_sdm, n_edm=n_e, k_edm=k_e, res_edm=r_e,
                n_corr=n_c, k_corr=k_c, res_corr=r_c, Rc_renorm=Rc_r, n_renorm=n_r, k_renorm=k_r, res_renorm=r_r,
                fwhm_model=fw_model, dth_rot=dth)


def main():
    rows = []
    for folder, sample, method in SETS:
        files = sorted(glob.glob(os.path.join(ROOT, folder, "*.txt")))
        scans = {}
        for f in files:
            m = NAME.search(os.path.basename(f))
            if m:
                scans.setdefault((m[1], int(m[2]), m[3]), []).append((int(m[4]), f))
        for (kind, lam, pol), lst in sorted(scans.items()):
            if kind == "air":
                continue
            airs = [(i, load(f)) for i, f in sorted(scans.get(("air", lam, pol), []))]
            for num, f in sorted(lst):
                med = load(f)
                if method == "slow":
                    cand = [a for i, a in airs if i == num]
                    air = cand[0] if cand else min((a for _, a in airs), key=lambda a: abs((a["time"] - med["time"]).total_seconds()))
                else:
                    air = min((a for _, a in airs), key=lambda a: abs((a["time"] - med["time"]).total_seconds()))
                r = analyze_pair(med, air, lam, pol)
                rows.append(dict(folder=folder, sample=sample, method=method, lam=lam, pol=pol, num=num,
                                 file=os.path.basename(f), air=os.path.basename(air["path"]), time=med["time"].isoformat(), **r))
                print(f"{folder:28s} {lam:5d} {pol} #{num:02d}: thc={r['theta_c']:.3f} Rc={r['Rc']:.3f}->{r['Rc_renorm']:.3f} "
                      f"fwhm={r['fwhm']:.2f}/model {r['fwhm_model']:.2f} plat={r['plateau']:.3f} | SDM {r['n_sdm']:.4f} | "
                      f"EDM {r['n_edm']:.4f} | corr {r['n_corr']:.4f} k={r['k_corr']:.1e} | renorm {r['n_renorm']:.4f} "
                      f"k={r['k_renorm']:.1e} (res {r['res_renorm']:.2f})")

    with open(os.path.join(RES, "turbid_scans.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(f"\n{len(rows)} scans -> results/turbid_scans.csv")


if __name__ == "__main__":
    main()
