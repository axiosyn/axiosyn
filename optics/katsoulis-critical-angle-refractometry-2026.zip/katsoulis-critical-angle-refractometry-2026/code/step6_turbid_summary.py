"""Step 6: summarize turbid-media indices with an uncertainty budget -> results/turbid_summary.csv"""
import csv
import math
import os
import sys
from collections import defaultdict

import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
rows = list(csv.DictReader(open(os.path.join(RES, "turbid_scans.csv"), encoding="utf-8")))
for r in rows:
    for k in ("lam", "num"):
        r[k] = int(r[k])
    for k in ("theta_c", "Rc", "fwhm", "plateau", "n_sdm", "n_edm", "k_edm", "n_corr", "k_corr", "n_renorm", "k_renorm", "fwhm_model", "res_renorm"):
        r[k] = float(r[k])

U_CAL = 8e-4      # absolute: session-to-session reproducibility found with water (rms of deviations from IAPWS)
U_ROT = 1e-4      # rotation-offset correction transferred from the 2020 water sessions
U_SIG = 1e-4      # angular-spread correction (sigma from water; 2021 alignment unknown)

def robust(v):
    v = np.asarray(v, float)
    med = np.median(v)
    mad = 1.4826 * np.median(np.abs(v - med)) if len(v) > 2 else np.inf
    keep = np.abs(v - med) <= max(5 * mad, 3e-4)
    return v[keep], int((~keep).sum())

G = defaultdict(list)
for r in rows:
    if r["res_renorm"] > 1.0:          # model could not reach the measured (theta_c, R_c)
        continue
    G[(r["sample"], r["lam"], r["method"], r["pol"])].append(r)

per_pol = []
for (s, lam, meth, pol), v in sorted(G.items()):
    n, nout = robust([x["n_renorm"] for x in v])
    per_pol.append(dict(sample=s, lam=lam, method=meth, pol=pol, N=len(n), outliers=nout,
                        n=float(n.mean()), sd=float(n.std(ddof=1)) if len(n) > 1 else float("nan"),
                        sem=float(n.std(ddof=1) / math.sqrt(len(n))) if len(n) > 1 else 3e-3,
                        n_sdm=float(np.mean([x["n_sdm"] for x in v])), n_edm=float(np.mean([x["n_edm"] for x in v])),
                        n_corr=float(np.mean([x["n_corr"] for x in v])),
                        k_med=float(np.median([x["k_renorm"] for x in v])),
                        fwhm_ratio=float(np.median([x["fwhm"] / x["fwhm_model"] for x in v if x["fwhm_model"] > 0]))))

# combine TE and TM (and slow/fast) per sample & wavelength
comb = []
for (s, lam) in sorted({(p["sample"], p["lam"]) for p in per_pol}):
    v = [p for p in per_pol if p["sample"] == s and p["lam"] == lam]
    w = np.array([1 / p["sem"] ** 2 for p in v]); x = np.array([p["n"] for p in v])
    mean = float((w * x).sum() / w.sum()); u_stat = float(1 / math.sqrt(w.sum()))
    te = [p["n"] for p in v if p["pol"] == "TE"]; tm = [p["n"] for p in v if p["pol"] == "TM"]
    d_pol = (np.mean(tm) - np.mean(te)) if te and tm else float("nan")
    u_pol = abs(d_pol) / 2 if np.isfinite(d_pol) else 0.0          # model inadequacy (sample is isotropic)
    u_meth = float(np.std([p["n"] for p in v], ddof=0)) if len({p["method"] for p in v}) > 1 else 0.0
    u_rel = math.sqrt(u_stat ** 2 + u_pol ** 2 + U_ROT ** 2 + U_SIG ** 2)
    u_abs = math.sqrt(u_rel ** 2 + U_CAL ** 2)
    comb.append(dict(sample=s, lam=lam, n=mean, u_stat=u_stat, d_TM_TE=d_pol, u_pol=u_pol, u_rel=u_rel, u_abs=u_abs,
                     n_sdm=float(np.mean([p["n_sdm"] for p in v])), n_edm=float(np.mean([p["n_edm"] for p in v])),
                     k_med=float(np.median([p["k_med"] for p in v])), fwhm_ratio=float(np.median([p["fwhm_ratio"] for p in v])),
                     N=int(sum(p["N"] for p in v))))

for name, data in (("turbid_per_pol.csv", per_pol), ("turbid_summary.csv", comb)):
    with open(os.path.join(RES, name), "w", newline="", encoding="utf-8") as fh:
        wr = csv.DictWriter(fh, fieldnames=list(data[0].keys())); wr.writeheader(); wr.writerows(data)

print("per polarization (renormalized, corrected EDM):")
for p in per_pol:
    print(f"  {p['sample']:10s} {p['lam']:5d} {p['method']:4s} {p['pol']} N={p['N']:2d} (out {p['outliers']}) n={p['n']:.5f} sd={p['sd']:.5f} | SDM {p['n_sdm']:.5f} EDM {p['n_edm']:.5f} corr {p['n_corr']:.5f} | k~{p['k_med']:.1e} width ratio {p['fwhm_ratio']:.1f}")
print("\ncombined:")
for c in comb:
    print(f"  {c['sample']:10s} {c['lam']:5d}  n = {c['n']:.4f} ± {c['u_rel']:.4f} (rel) ± {c['u_abs']:.4f} (abs)  TM-TE = {c['d_TM_TE']*1e4:+.1f}e-4  "
          f"[SDM {c['n_sdm']:.4f}, EDM {c['n_edm']:.4f}]  k~{c['k_med']:.1e}  N={c['N']}")
