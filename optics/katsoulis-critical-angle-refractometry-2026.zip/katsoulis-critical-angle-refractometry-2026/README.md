# Critical-angle refractometry of water, Intralipid and milk cream

**Ierotheos Katsoulis** · self-published preprints, November 2026 · not peer-reviewed

Measurements made at the Electronic Devices and Materials Laboratory (EDML), Department of Electrical and Electronic Engineering, University of West Attica, during an MSc by Research supervised by Prof. Konstantinos Moutzouris (2020–2021). Analysis and writing 2026.

## Main findings

- **Water is not birefringent at a prism interface:** |n<sub>TM</sub> − n<sub>TE</sub>| < 2 × 10⁻⁵ (95 % confidence) from 532 to 1551 nm.
- **The standard derivative method makes isotropic samples look birefringent.** It reports n<sub>TM</sub> − n<sub>TE</sub> = +3 to +8 × 10⁻⁵ for water. The size of this artefact can be predicted from the measured peak shapes, and it is proportional to (n<sub>p</sub>/n)² − 1.
- **The direction of table rotation shifts the measured index by ±5 × 10⁻⁴** on this instrument. Averaging both directions removes it.
- **Intralipid at 25 °C, relative to air:** n = 1.3691 (532 nm), 1.3595 (964 nm), 1.3515 (1551 nm), ± 0.0008.
- **Milk cream (35 % fat) does not give a reliable index** by this method; the papers explain why.

## Contents

| Folder / file | What it is |
| --- | --- |
| `papers/Paper1b_Methods_apparent_birefringence.pdf` | **Start here.** The polarization bias of the derivative method, demonstrated on water (9 pages) |
| `papers/Paper2_Intralipid_cream_refractive_index.pdf` | Complex refractive index of Intralipid and milk cream (7 pages) |
| `papers/Paper1_Water_TE_TM_refractometry_full_draft.pdf` | Full water study: anisotropy, dispersion, temperature dependence (11 pages) |
| `figures/` | All figures as PNG |
| `data_sample/` | 16 raw scans (water, Intralipid, cream) and their file format; shared for verification only |
| `code/` | Complete analysis code, summary result tables, and `demo_sample.py` |
| `LICENSE.md`, `CITATION.cff` | Licenses and how to cite |

## Data availability

Only a representative sample of the raw measurements is included. The full dataset (252 water scans, and 115 Intralipid and cream scans with their air references) was recorded at EDML, UNIWA. It may be the property of the laboratory and is not disclosed.

## Reproducing results

```
pip install -r code/requirements.txt
cd code
python demo_sample.py
```

`demo_sample.py` analyses the 16 sample scans and prints them next to the values reported in the papers. Single scans agree with the full-dataset means to about 1 × 10⁻⁴. The scripts `step1_scans.py` to `step8_turbid_profiles.py` reproduce every number and figure from the full dataset. They expect it in `../Ierotheos/` (water) and `../Measurments_Iero/Turbid Media/` relative to `code/`, so they will not run on the sample alone. `make_pdfs.py` rebuilds the PDFs from Markdown sources; it uses Microsoft Edge to print.

## Licenses

Papers and figures: **CC BY 4.0**. Use them for anything, with credit. Code and summary tables: **MIT**. Sample data: not licensed for reuse (see `data_sample/README.md`). Details in `LICENSE.md`.

## How to cite

> I. Katsoulis, "Apparent birefringence in critical-angle refractometry: a polarization bias of the derivative method," self-published preprint, November 2026.

The other two papers can be cited the same way, by title. `CITATION.cff` has all three.

## Known open issues

- The Intralipid concentration is not recorded; the measured indices fit a 20 % emulsion best.
- The papers have not been compared yet with the published Intralipid values of Ding et al. (2005) and Dong et al. (2013).
- All results come from one instrument. The bias correction has not yet been tested on a sample of known small birefringence.
