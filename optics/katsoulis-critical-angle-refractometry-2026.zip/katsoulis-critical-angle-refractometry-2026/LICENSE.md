# Licenses

| Part of this package | License |
| --- | --- |
| `papers/` (text, tables, equations) and `figures/` | Creative Commons Attribution 4.0 International (CC BY 4.0) |
| `code/` (analysis scripts) and `code/results/` (summary tables produced by the code) | MIT License (see `code/LICENSE`) |
| `data_sample/` (raw measurement files) | **Not licensed for reuse.** Shared for verification only; rights may belong to the Electronic Devices and Materials Laboratory (EDML), University of West Attica. See `data_sample/README.md`. |

## CC BY 4.0 in short

Copyright © 2026 Ierotheos Katsoulis.

You are free to **share** (copy and redistribute in any medium or format) and **adapt** (remix, transform and build upon) the papers and figures, for any purpose, including commercially, provided you give **appropriate credit**. Credit means naming the author, giving the title, indicating the license, and indicating whether you made changes. You may not apply legal terms or technological measures that restrict others from doing anything the license permits.

Full legal code: https://creativecommons.org/licenses/by/4.0/legalcode

Suggested credit line: *"Figure/text from I. Katsoulis, [paper title], self-published preprint (2026), licensed CC BY 4.0."*
