# Sample measurement data

**Rights:** these 16 files are a small sample of the raw measurements, shared only so that readers can check the data format and the analysis. The measurements were recorded at the Electronic Devices and Materials Laboratory (EDML), University of West Attica (UNIWA), in 2020–2021. The full dataset may be the property of EDML, UNIWA and is not disclosed. These sample files are **not** covered by the CC BY 4.0 license of the papers or the MIT license of the code.

## Contents

| Folder | Files | What they are |
| --- | --- | --- |
| `water/` | 8 | Water, 25 °C, at 964 nm and 1551 nm; TE and TM; both table-rotation directions (L, R) |
| `intralipid_1551nm/` | 4 | Intralipid at 1551 nm, TE and TM, each with its air reference scan |
| `cream_633nm/` | 4 | Milk cream (35 % fat) at 633 nm, TE and TM, each with its air reference scan |

File names: `<sample>_<wavelength nm>_<temperature °C>_<TE|TM>_<repeat>_<L|R>` for water, and `<sample>_<wavelength nm>_<TE|TM>_R_<repeat>` for the turbid media and their air references. L and R give the direction in which the rotary table was turning during the scan.

## Format

Each file is one angular scan exported by a Metricon 2010/M prism coupler, as comma-separated text.

- **Line 1:** scan name, timestamp, `TempCo` (the prism's dn/dT in units of 10⁻⁵ K⁻¹) and `Temp` (prism temperature set point, °C).
- **Line 3:** column headers.
- **Following lines:** one row per table position.

| Column | Meaning |
| --- | --- |
| `TablePos` | rotary-table step |
| `ExtAngle` | external angle of incidence on the prism (deg) |
| `IntAngle` | internal angle of incidence at the prism base (deg) |
| `Beta` | n_prism(T) · sin(IntAngle), i.e. the index that total internal reflection would imply at this angle |
| `I` | detector reading (counts) |
| `%I`, `Smooth %I` | instrument-normalized intensity and its smoothed version |

The analysis uses `IntAngle`, `Beta` (from which the temperature-corrected prism index follows) and `I`. For Intralipid and cream, the reflectance is `I_medium / I_air` on a common internal-angle grid.
